/*
 * This file is part of the Score-P software (http://www.score-p.org)
 *
 * Copyright (c) 2014,
 * Technische Universitaet Dresden, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license. See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef SCOREP_OMPT_TPD_H
#define SCOREP_OMPT_TPD_H

#include <ompt.h>
#include <stdint.h>

#define SCOREP_OMPT_REGION_STACK_SIZE 16

typedef struct
{
    ompt_thread_id_t tid;
    uint64_t         regionStack[ SCOREP_OMPT_REGION_STACK_SIZE ];
    int32_t          currentStackLevel;
    uint64_t         currentTaskRegionId;
    uint64_t         taskEnterTimestamp;
} scorep_ompt_tpd_t;

void
SCOREP_Ompt_Tpd_Init();

void
SCOREP_Ompt_Tpd_Finalize();

// Returns the TPD for the thread with id @tid
// Asserts that it exists (created with Tpd_Add)
scorep_ompt_tpd_t*
SCOREP_Ompt_Tpd_Get( ompt_thread_id_t tid );

// Creates the TPD for thread id @tid
void
SCOREP_Ompt_Tpd_Add( ompt_thread_id_t tid );

// Removes the TPD for thread id @tid
// Should be called on thread end to free the memory
void
SCOREP_Ompt_Tpd_Remove( ompt_thread_id_t tid );

#endif  /* SCOREP_OMPT_TPD_H */

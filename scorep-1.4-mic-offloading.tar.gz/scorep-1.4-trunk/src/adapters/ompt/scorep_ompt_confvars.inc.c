/*
 * This file is part of the Score-P software (http://www.score-p.org)
 *
 * Copyright (c) 2014, 2015
 * Technische Universitaet Dresden, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license. See the COPYING file in the package base
 * directory for details.
 *
 */


/**
 * @file
 *
 *
 */

#include <config.h>

uint64_t scorep_ompt_features;


/*
 * Mapping of options for OMPT measurement to internal representation
 * (bit mask).
 */
static const SCOREP_ConfigType_SetEntry scorep_ompt_enable_groups[] =
{
    { "thread",        SCOREP_OMPT_FEATURE_THREAD               },
    { "parallel",      SCOREP_OMPT_FEATURE_PARALLEL             },
    { "loop",          SCOREP_OMPT_FEATURE_LOOP                 },
    { "barrier",       SCOREP_OMPT_FEATURE_BARRIER              },
    { "wait_barrier",  SCOREP_OMPT_FEATURE_WAIT_BARRIER         },
    { "task",          SCOREP_OMPT_FEATURE_TASK                 },
    { "implicit_task", SCOREP_OMPT_FEATURE_IMPLICIT_TASK        },
    { "target",        SCOREP_OMPT_FEATURE_TARGET               },
    { "device",        SCOREP_OMPT_FEATURE_DEVICE               },
    { "idle",          SCOREP_OMPT_FEATURE_IDLE                 },
    { "shutdown",      SCOREP_OMPT_FEATURE_SHUTDOWN             },
    { "opari",         SCOREP_OMPT_FEATURES_OPARI               },
    { "1",             SCOREP_OMPT_FEATURES_DEFAULT             },
    { "yes",           SCOREP_OMPT_FEATURES_DEFAULT             },
    { "true",          SCOREP_OMPT_FEATURES_DEFAULT             },
    { "no",            0                                        },
    { NULL,            0                                        }
};


/*
 *  Configuration variables for the OMPT adapter.
 */
static SCOREP_ConfigVariable scorep_ompt_configs[] =
{
    {
        "enable",
        SCOREP_CONFIG_TYPE_BITSET, /* type */
        &scorep_ompt_features,     /* pointer to target variable */
        ( void* )scorep_ompt_enable_groups,
        "no",                      /* default value */
        "OMPT measurement features",
        "Sets the OMPT measurement mode to capture:\n"
        "  thread:        thread lifetime\n"
        "  parallel:      parallel regions\n"
        "  loop:          loops\n"
        "  barrier:       barriers\n"
        "  wait_barrier:  waiting time in barriers\n"
        "  task:          explicit tasks\n"
        "  implicit_task: implicit tasks\n"
        "  idle:          thread idle time\n"
        "  target:        target regions\n"
        "  shutdown:      OpenMP runtime shutdown\n"
        "  opari:         Similar event set as recorded with OPARI\n"
        "  default/yes/1: all events\n"
        "  no:            Disable OMPT measurement\n"
    },
    SCOREP_CONFIG_TERMINATOR
};

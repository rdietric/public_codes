/*
 * This file is part of the Score-P software (http://www.score-p.org)
 *
 * Copyright (c) 2014,
 * Technische Universitaet Dresden, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license. See the COPYING file in the package base
 * directory for details.
 *
 */

/**
 *  @file
 *
 *  This file contains the implementation of the initialization functions of
 *  the OMPT adapter.
 */

#include <config.h>

#include <SCOREP_RuntimeManagement.h>
#include <SCOREP_Definitions.h>
#include <SCOREP_Events.h>
#include "SCOREP_Config.h"
#include "SCOREP_Types.h"
#include <SCOREP_Location.h>
#include <SCOREP_ThreadForkJoin_Event.h>
#include <SCOREP_Omp_Target.h>

#include <omp.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>


#include <UTILS_Error.h>
#define SCOREP_DEBUG_MODULE_NAME OMPT
#include <UTILS_Debug.h>

#include "SCOREP_Ompt_Init.h"
#include "scorep_ompt.h"
#include "SCOREP_Ompt_Regions.h"
#include "scorep_ompt_confvars.inc.c"

/** Registers the required configuration variables of the OMPT adapter
    to the measurement system.
 */
static SCOREP_ErrorCode
ompt_register( size_t subsystem_id )
{
    scorep_ompt_subsystem_id = subsystem_id;

    return SCOREP_ConfigRegister( "ompt", scorep_ompt_configs );
}

static int
scorep_ompt_finalize_callback( void )
{
    UTILS_DEBUG_ENTRY();
    scorep_ompt_before_finalize();
    return 0;
}

/** Initializes the OMPT adapter. */
static SCOREP_ErrorCode
ompt_init( void )
{
    UTILS_DEBUG_ENTRY();
    if ( scorep_ompt_features > 0 )
    {
        SCOREP_RegisterExitCallback( scorep_ompt_finalize_callback );
    }

    scorep_ompt_initialize();
    SCOREP_Omp_Target_Init();

    return SCOREP_SUCCESS;
}

/** Finalizes the OMPT adapter. */
static void
ompt_finalize( void )
{
    UTILS_DEBUG_ENTRY();
    scorep_ompt_finalize();
}

/** Collect locations involved in POMP target communication. */
static SCOREP_ErrorCode
ompt_pre_unify( void )
{
    UTILS_DEBUG_ENTRY();
    scorep_omp_define_target_locations();

    return SCOREP_SUCCESS;
}

static SCOREP_ErrorCode
ompt_post_unify( void )
{
    UTILS_DEBUG_ENTRY();
    scorep_omp_define_target_group();

    return SCOREP_SUCCESS;
}


SCOREP_Subsystem SCOREP_Subsystem_OmptAdapter =
{
    .subsystem_name              = "OMPT",
    .subsystem_register          = &ompt_register,
    .subsystem_init              = &ompt_init,
    .subsystem_init_location     = NULL,
    .subsystem_finalize_location = NULL,
    .subsystem_pre_unify         = &ompt_pre_unify,
    .subsystem_post_unify        = &ompt_post_unify,
    .subsystem_finalize          = &ompt_finalize,
    .subsystem_deregister        = NULL,
    .subsystem_control           = NULL
};

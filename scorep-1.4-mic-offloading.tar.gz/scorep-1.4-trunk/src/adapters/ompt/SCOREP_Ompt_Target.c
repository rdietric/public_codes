/*
 * This file is part of the Score-P software (http://www.score-p.org)
 *
 * Copyright (c) 2009-2011,
 * RWTH Aachen University, Germany
 *
 * Copyright (c) 2009-2011,
 * Gesellschaft fuer numerische Simulation mbH Braunschweig, Germany
 *
 * Copyright (c) 2009-2011,2014
 * Technische Universitaet Dresden, Germany
 *
 * Copyright (c) 2009-2011,
 * University of Oregon, Eugene, USA
 *
 * Copyright (c) 2009-2013,
 * Forschungszentrum Juelich GmbH, Germany
 *
 * Copyright (c) 2009-2011,
 * German Research School for Simulation Sciences GmbH, Juelich/Aachen, Germany
 *
 * Copyright (c) 2009-2011,
 * Technische Universitaet Muenchen, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 */

#include <config.h>
#include <opari2/pomp2_lib.h>
#include <SCOREP_Omp_Target_Events.h>

#include "SCOREP_Ompt_Regions.h"

void
POMP2_Target_begin( POMP2_Region_handle* pomp_handle, int deviceId )
{
    scorep_ompt_region_t* region = *( ( scorep_ompt_region_t** )pomp_handle );
    SCOREP_Omp_Target_begin( region->handle, deviceId );
}

void
POMP2_Target_end( POMP2_Region_handle* pomp_handle, int deviceId )
{
    scorep_ompt_region_t* region = *( ( scorep_ompt_region_t** )pomp_handle );
    SCOREP_Omp_Target_end( region->handle, deviceId );
}

void
POMP2_Target_flush( POMP2_Region_handle* pomp_handle, int deviceId )
{
    scorep_ompt_region_t* region = *( ( scorep_ompt_region_t** )pomp_handle );
    SCOREP_Omp_Target_flush( region->handle, deviceId );
}

void
POMP2_Target_copy_begin( POMP2_Region_handle* pomp_handle, uint8_t direction, int deviceId )
{
    scorep_ompt_region_t* region = *( ( scorep_ompt_region_t** )pomp_handle );
    SCOREP_Omp_Target_copy_begin( region->handle, direction, deviceId );
}

void
POMP2_Target_copy_end( POMP2_Region_handle* pomp_handle, uint8_t direction, int deviceId )
{
    scorep_ompt_region_t* region = *( ( scorep_ompt_region_t** )pomp_handle );
    SCOREP_Omp_Target_copy_end( region->handle, direction, deviceId );
}

void
POMP2_Target_update_begin( POMP2_Region_handle* pomp_handle, uint8_t direction, int deviceId )
{
    scorep_ompt_region_t* region = *( ( scorep_ompt_region_t** )pomp_handle );
    SCOREP_Omp_Target_update_begin( region->handle, direction, deviceId );
}

void
POMP2_Target_update_end( POMP2_Region_handle* pomp_handle, uint8_t direction, int deviceId )
{
    scorep_ompt_region_t* region = *( ( scorep_ompt_region_t** )pomp_handle );
    SCOREP_Omp_Target_update_end( region->handle, direction, deviceId );
}

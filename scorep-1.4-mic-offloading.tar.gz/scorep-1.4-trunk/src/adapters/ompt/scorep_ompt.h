/*
 * This file is part of the Score-P software (http://www.score-p.org)
 *
 * Copyright (c) 2014, 2015
 * Technische Universitaet Dresden, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license. See the COPYING file in the package base
 * directory for details.
 *
 */

/**
 *  @file
 *
 *  This file provides commonly used types and definitions for the OMPT
 *  adapter.
 */

#ifndef SCOREP_OMPT_H
#define SCOREP_OMPT_H


#include <ompt.h>
#include <SCOREP_Location.h>

// Is OPARI used for source code information and target instrumentation?
//#define OPARI 1

/*
 * OMPT features (to be enabled/disabled via environment variables)
 */
#define SCOREP_OMPT_FEATURE_THREAD                 ( 1 << 0 )
#define SCOREP_OMPT_FEATURE_PARALLEL               ( 1 << 1 )
#define SCOREP_OMPT_FEATURE_LOOP                   ( 1 << 2 )
#define SCOREP_OMPT_FEATURE_BARRIER                ( 1 << 3 )
#define SCOREP_OMPT_FEATURE_WAIT_BARRIER           ( 1 << 4 )
#define SCOREP_OMPT_FEATURE_TASK                   ( 1 << 5 )
#define SCOREP_OMPT_FEATURE_IMPLICIT_TASK          ( 1 << 6 )
#define SCOREP_OMPT_FEATURE_TARGET                 ( 1 << 7 )
#define SCOREP_OMPT_FEATURE_DEVICE                 ( 1 << 8 )
#define SCOREP_OMPT_FEATURE_IDLE                   ( 1 << 9 )
#define SCOREP_OMPT_FEATURE_SHUTDOWN               ( 1 << 10 )

#define SCOREP_OMPT_FEATURES_DEFAULT \
    ( SCOREP_OMPT_FEATURE_PARALLEL | SCOREP_OMPT_FEATURE_LOOP | \
      SCOREP_OMPT_FEATURE_BARRIER | SCOREP_OMPT_FEATURE_WAIT_BARRIER | \
      SCOREP_OMPT_FEATURE_IMPLICIT_TASK | SCOREP_OMPT_FEATURE_IDLE | \
      SCOREP_OMPT_FEATURE_THREAD | SCOREP_OMPT_FEATURE_TASK | \
      SCOREP_OMPT_FEATURE_TARGET )

#define SCOREP_OMPT_FEATURES_OPARI \
    ( SCOREP_OMPT_FEATURE_PARALLEL | SCOREP_OMPT_FEATURE_LOOP | \
      SCOREP_OMPT_FEATURE_TASK | SCOREP_OMPT_FEATURE_IMPLICIT_TASK | \
      SCOREP_OMPT_FEATURE_BARRIER )

/*
 * Specifies the OMPT events to be recorded with a bit mask.
 * See SCOREP_ConfigType_SetEntry of OMPT adapter.
 */
extern uint64_t scorep_ompt_features;

/**
 * Gets called by scorep before the finalizing is done, so locations are still writable
 */
void
scorep_ompt_before_finalize();

void
scorep_ompt_finalize( void );

void
scorep_ompt_initialize( void );

#endif /* SCOREP_OMPT_H */

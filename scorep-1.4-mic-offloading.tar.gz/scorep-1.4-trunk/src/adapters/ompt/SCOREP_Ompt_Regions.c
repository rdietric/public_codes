/*
 * This file is part of the Score-P software (http://www.score-p.org)
 *
 * Copyright (c) 2013,
 * Forschungszentrum Juelich GmbH, Germany
 *
 * Copyright (c) 2014,
 * Technische Universitaet Dresden, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 *
 */

#include <config.h>

#include <stdbool.h>
#include <string.h>
#include <inttypes.h>
#include <math.h>
#include <stdlib.h>

#include <SCOREP_Memory.h>


#include <UTILS_IO.h>
#define SCOREP_DEBUG_MODULE_NAME OMPT
#include <UTILS_Debug.h>
#include <UTILS_Error.h>

#include <SCOREP_Definitions.h>

#include "SCOREP_Ompt_Regions.h"
#include <opari2/pomp2_lib.h>
#include <pomp2_region_info.h>

/** Contains the data for one region type */
typedef struct
{
    char*             regionTypeString;
    SCOREP_RegionType regionType;
} ompt_region_type_map_entry;

/** Maps region name in the information string to POMP2_Region_type
 */
static const ompt_region_type_map_entry ompt_region_type_map[] =
{
    /* Entries must be sorted to be used in binary search. */
    /* Entries must be in same order like POMP2_Region_type to allow lookup. */
    { "notype",             SCOREP_REGION_UNKNOWN                   },
    { "atomic",             SCOREP_REGION_ATOMIC                    },
    { "barrier",            SCOREP_REGION_BARRIER                   },
    { "critical",           SCOREP_REGION_CRITICAL                  },
    { "do",                 SCOREP_REGION_LOOP                      },
    { "flush",              SCOREP_REGION_FLUSH                     },
    { "for",                SCOREP_REGION_LOOP                      },
    { "master",             SCOREP_REGION_UNKNOWN                   },
    { "ordered",            SCOREP_REGION_ORDERED                   },
    { "parallel",           SCOREP_REGION_UNKNOWN                   },
    { "parallel do",        SCOREP_REGION_LOOP                      },
    { "parallel for",       SCOREP_REGION_LOOP                      },
    { "parallel sections",  SCOREP_REGION_SECTIONS                  },
    { "parallel workshare", SCOREP_REGION_WORKSHARE                 },
    { "sections",           SCOREP_REGION_SECTIONS                  },
    { "single",             SCOREP_REGION_SINGLE                    },
    { "target",             SCOREP_REGION_CODE                      },
    { "targetdatamap",      SCOREP_REGION_CODE                      },
    { "targetmap",          SCOREP_REGION_CODE                      },
    { "targetupdate",       SCOREP_REGION_CODE                      },
    { "task",               SCOREP_REGION_TASK_CREATE               },
    { "task",               SCOREP_REGION_TASK_CREATE               },
    { "taskwait",           SCOREP_REGION_TASK_WAIT                 },
    { "region",             SCOREP_REGION_UNKNOWN                   },
    { "workshare",          SCOREP_REGION_WORKSHARE                 }
};

static scorep_ompt_region_t* ompt_regions      = NULL;
static unsigned              ompt_region_count = 0;

// create the region name array as lookup
#define OMPT_REGION_TYPE( NAME, name_str ) \
    name_str,
const char* ompt_region_type_to_string[] = { OMPT_REGION_TYPES };


/** ID of the OMPT subsystem */
size_t scorep_ompt_subsystem_id = 0;

/** @def OMPT_REGIONS_HASHTABLE_SIZE
 *  the default size for the OMPT regions hash table */
#define OMPT_REGIONS_HASHTABLE_SIZE 1024

static ompt_region_t* regions_hashtab[ OMPT_REGIONS_HASHTABLE_SIZE ];

static inline uint32_t
hash_ptr( void* ptr )
{
    return ( uint32_t )( ( size_t )ptr >> ( size_t )log2( 1 + sizeof( void ) ) );
}

SCOREP_RegionHandle
scorep_ompt_region_get( ompt_region_type type, void* func )
{
    uint32_t hash = hash_ptr( func );
    uint32_t id   = hash & ( OMPT_REGIONS_HASHTABLE_SIZE - 1 );

    // get the bucket
    ompt_region_t* curr = regions_hashtab[ id ];

    // iterate over bucket
    while ( curr )
    {
        // check if bucket entry has the same function address and Score-P region type
        if ( curr->func == func && curr->type == type )
        {
            return curr->handle;
        }
        curr = curr->next;
    }

    // region not found, therefore create entry
    curr       = ( ompt_region_t* )SCOREP_Memory_AllocForMisc( sizeof( ompt_region_t ) );
    curr->type = type;
    curr->func = func;

    // generate Score-P region handle
    const char* type_name   = ompt_region_type_to_string[ type ];
    int         length      = 4 + strlen( type_name ) + 1;
    char*       region_name = NULL;
    int         error       = -1;

    if ( NULL == func )
    {
        // no function pointer given
        region_name = ( char* )SCOREP_Memory_AllocForMisc( length );
        error       = snprintf( region_name, length, "omp %s", type_name );
    }
    else
    {
        // function pointer is given (add to name))
        length     += 9;
        region_name = ( char* )SCOREP_Memory_AllocForMisc( length );
        error       = snprintf( region_name, length, "omp %s@%p", type_name, func );
    }

    if ( -1 == error )
    {
        UTILS_WARNING( "[OMPT] Could not create region name for %s!", type_name );
        region_name = ( char* )type_name;
    }
    curr->handle = SCOREP_Definitions_NewRegion( region_name, NULL,
                                                 SCOREP_INVALID_SOURCE_FILE, 0, 0,
                                                 SCOREP_PARADIGM_OPENMP,
                                                 type );

    // prepend in bucket
    curr->next            = regions_hashtab[ id ];
    regions_hashtab[ id ] = curr;

    return curr->handle;
}

scorep_ompt_location_data*
ompt_region_location_init( SCOREP_Location* location )
{
    scorep_ompt_location_data* loc_data =
        ( scorep_ompt_location_data* )SCOREP_Memory_AllocForMisc( sizeof( scorep_ompt_location_data ) );

    loc_data->curr_target_device = NULL;
    loc_data->in_callback        = false;
    loc_data->stack_depth        = 0;
    loc_data->stack_depth_max    = 0;
    loc_data->map_list           = NULL;
    loc_data->region_stack       = NULL;

    // allocate dummy element as bottom of the stack
    region_stack_element* dummy_region =
        ( region_stack_element* )SCOREP_Memory_AllocForMisc( sizeof( region_stack_element ) );

    dummy_region->handle = SCOREP_INVALID_REGION;
    dummy_region->next   = NULL;
    dummy_region->prev   = NULL;

    loc_data->region_stack = dummy_region;

    // set the locations subsystem data
    SCOREP_Location_SetSubsystemData( location,
                                      scorep_ompt_subsystem_id, loc_data );

    return loc_data;
}

void
ompt_region_push( SCOREP_RegionHandle region )
{
    SCOREP_Location* location = SCOREP_Location_GetCurrentCPULocation();

    scorep_ompt_location_data* loc_data =
        SCOREP_Location_GetSubsystemData( location,
                                          scorep_ompt_subsystem_id );

    if ( NULL == loc_data )
    {
        loc_data = ompt_region_location_init( location );
    }

    region_stack_element* new = NULL;

    if ( loc_data->stack_depth < loc_data->stack_depth_max )
    {
        // already allocated
        new = loc_data->region_stack->next;
    }
    else
    {
        // not yet allocated
        new = ( region_stack_element* )SCOREP_Memory_AllocForMisc(
            sizeof( region_stack_element ) );
        new->next = NULL;
        new->prev = loc_data->region_stack;

        // set the next pointer of the previous element
        if ( loc_data->region_stack )
        {
            loc_data->region_stack->next = new;
        }

        loc_data->stack_depth_max++;
    }

    new->handle = region;

    // change stack depth and stack pointer
    loc_data->stack_depth++;
    loc_data->region_stack = new;
}

SCOREP_RegionHandle
ompt_region_pop( void )
{
    scorep_ompt_location_data* loc_data =
        SCOREP_Location_GetSubsystemData( SCOREP_Location_GetCurrentCPULocation(),
                                          scorep_ompt_subsystem_id );

    UTILS_ASSERT( loc_data && loc_data->stack_depth >= 0 );

    SCOREP_RegionHandle handle = loc_data->region_stack->handle;

    loc_data->stack_depth--;

    loc_data->region_stack = loc_data->region_stack->prev;

    return handle;
}


void
ompt_map_push( ompt_data_map_id_t mapId, ompt_data_map_t mapType )
{
    SCOREP_Location* location = SCOREP_Location_GetCurrentCPULocation();

    scorep_ompt_location_data* loc_data =
        SCOREP_Location_GetSubsystemData( location,
                                          scorep_ompt_subsystem_id );

    if ( NULL == loc_data )
    {
        loc_data = ompt_region_location_init( location );
    }

    map_element* new = loc_data->map_list;

    // lookup empty element
    while ( NULL != new )
    {
        if ( new->empty == true )
        {
            break;
        }

        new = new->next;
    }

    // not yet allocated?
    if ( !new )
    {
        new = ( map_element* )SCOREP_Memory_AllocForMisc(
            sizeof( map_element ) );

        //prepend
        new->next          = loc_data->map_list;
        loc_data->map_list = new;
    }

    // set map data
    new->map_type    = mapType;
    new->data_map_id = mapId;
    new->empty       = false;
}

ompt_data_map_t
ompt_map_pop( ompt_data_map_id_t mapId )
{
    scorep_ompt_location_data* loc_data =
        SCOREP_Location_GetSubsystemData( SCOREP_Location_GetCurrentCPULocation(),
                                          scorep_ompt_subsystem_id );

    UTILS_ASSERT( loc_data && loc_data->map_list );

    map_element* elem = loc_data->map_list;

    // lookup empty element
    while ( NULL != elem )
    {
        if ( elem->data_map_id == mapId && elem->empty == false )
        {
            elem->empty = true;
            return elem->map_type;
        }

        elem = elem->next;
    }

    return ompt_data_map_INVALID;
}

void
scorep_ompt_regions_init()
{
    int i;
    ompt_region_count = POMP2_Get_num_regions();
    ompt_regions      = ( scorep_ompt_region_t* )
                        SCOREP_Memory_AllocForMisc( sizeof( scorep_ompt_region_t ) * ompt_region_count );
    for ( i = 0; i < ompt_region_count; ++i )
    {
        ompt_regions[ i ].handle = SCOREP_INVALID_REGION;
        ompt_regions[ i ].id     = 0;
    }

    /* Register regions inserted by OPARI */
    POMP2_Init_regions();
}

scorep_ompt_region_t*
scorep_ompt_regions_get( size_t id )
{
    for ( int i = 0; i < ompt_region_count; i++ )
    {
        if ( ompt_regions[ i ].id == id )
        {
            return &ompt_regions[ i ];
        }
    }
    return NULL;
}

SCOREP_RegionHandle
scorep_ompt_regions_getHandle( size_t id )
{
    scorep_ompt_region_t* region = scorep_ompt_regions_get( id );
    UTILS_BUG_ON( region == NULL, "Unknown region id %u", id );
    return region->handle;
}

static void
scorep_ompt_register_region( POMP2_Region_info* regionInfo, scorep_ompt_region_t* region )
{
    SCOREP_ParadigmType paradigm = SCOREP_PARADIGM_OPENMP;
    /* Assume that all regions from one file are registered in a row.
       Thus, remember the last file handle and reuse it if the next region stems
       from the same source file.                                                 */
    static char*                   last_file_name = 0;
    static SCOREP_SourceFileHandle last_file      = SCOREP_INVALID_SOURCE_FILE;
    UTILS_ASSERT( regionInfo );
    UTILS_ASSERT( region );

    /* Consistency checks */
    if ( ( regionInfo->mRegionType < 0 ) ||
         ( regionInfo->mRegionType > POMP2_Workshare ) )
    {
        UTILS_ERROR( SCOREP_ERROR_INDEX_OUT_OF_BOUNDS,
                     "Region type %d not found in region type table.",
                     regionInfo->mRegionType );
        exit( EXIT_FAILURE );
    }

    /* Evtl. register new source file */
    if ( ( last_file == SCOREP_INVALID_SOURCE_FILE ) ||
         strcmp( last_file_name, regionInfo->mStartFileName ) )
    {
        last_file_name = regionInfo->mStartFileName;
        last_file      = SCOREP_Definitions_NewSourceFile( last_file_name );
    }

    /* Construct file:lno string */
    const char* basename = UTILS_IO_GetWithoutPath( last_file_name );
    // SCOREP_Memory_AllocForMisc does not work here
    char* source_name = ( char* )malloc( strlen( basename ) + 12 );
    sprintf( source_name, "@%s:%" PRIi32, basename, regionInfo->mStartLine1 );

    char* type_name   = ompt_region_type_map[ regionInfo->mRegionType ].regionTypeString;
    int   length      = strlen( type_name ) + 7 + strlen( source_name ) + 1;
    char* region_name = ( char* )malloc( length );
    sprintf( region_name, "!$omp %s %s", type_name, source_name );

    region->handle = SCOREP_Definitions_NewRegion( region_name,
                                                   NULL,
                                                   last_file,
                                                   regionInfo->mStartLine1,
                                                   regionInfo->mEndLine1,
                                                   paradigm,
                                                   ompt_region_type_map[ regionInfo->mRegionType ].regionType );
    region->type = regionInfo->mRegionType;

    free( region_name );
    free( source_name );
}

static void
scorep_ompt_parse_init_string( const char            initString[],
                               scorep_ompt_region_t* region )
{
    UTILS_ASSERT( region );
    POMP2_Region_info regionInfo;


    ctcString2RegionInfo( initString, &regionInfo );

    scorep_ompt_register_region( &regionInfo, region );

    /*free regionInfo since all information is copied to Score-P */
    freePOMP2RegionInfoMembers( &regionInfo );
}

void
POMP2_Assign_handle( POMP2_Region_handle* pomp_handle,
                     const char           init_string[] )
{
    UTILS_DEBUG_ENTRY();
    UTILS_ASSERT( ompt_regions );

    /* Index counter */
    static size_t count = 0;
    UTILS_ASSERT( count < POMP2_Get_num_regions() );

    *pomp_handle = ( POMP2_Region_handle ) & ompt_regions[ count ];

    /* Initialize new region struct */
    scorep_ompt_parse_init_string( init_string, *pomp_handle );

    /* Increase array index */
    ++count;
}

void
POMP2_Target_map_region( POMP2_Region_handle* pomp_handle, size_t id )
{
    UTILS_ASSERT( id );
    UTILS_ASSERT( *pomp_handle );
    UTILS_BUG_ON( scorep_ompt_regions_get( id ), "Region id %u already in use!", id );
    scorep_ompt_region_t* region = *( ( scorep_ompt_region_t** )pomp_handle );
    region->id = id;
}

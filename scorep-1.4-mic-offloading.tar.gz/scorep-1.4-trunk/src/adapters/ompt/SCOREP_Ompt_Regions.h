/*
 * This file is part of the Score-P software (http://www.score-p.org)
 *
 * Copyright (c) 2009-2011,
 * RWTH Aachen University, Germany
 *
 * Copyright (c) 2009-2011,
 * Gesellschaft fuer numerische Simulation mbH Braunschweig, Germany
 *
 * Copyright (c) 2009-2011,2014,
 * Technische Universitaet Dresden, Germany
 *
 * Copyright (c) 2009-2011,
 * University of Oregon, Eugene, USA
 *
 * Copyright (c) 2009-2013,
 * Forschungszentrum Juelich GmbH, Germany
 *
 * Copyright (c) 2009-2011,
 * German Research School for Simulation Sciences GmbH, Juelich/Aachen, Germany
 *
 * Copyright (c) 2009-2011,
 * Technische Universitaet Muenchen, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 */

#ifndef SCOREP_OMPT_REGIONS_H
#define SCOREP_OMPT_REGIONS_H

#include <SCOREP_Types.h>
#include <SCOREP_Location.h>

#include <pomp2_region_info.h>

#include <ompt.h>

#define OMPT_REGION_TYPE( NAME, name_str ) \
    OMPT_REGION_ ## NAME,

#define OMPT_REGION_TYPES \
    OMPT_REGION_TYPE( PARALLEL,      "parallel" ) \
    OMPT_REGION_TYPE( TASK,          "task" ) \
    OMPT_REGION_TYPE( TARGET,        "target" ) \
    OMPT_REGION_TYPE( TARGET_DATA,   "target data" ) \
    OMPT_REGION_TYPE( TARGET_UPDATE, "target update" ) \
    OMPT_REGION_TYPE( TARGET_INVOKE, "target invoke" )

/** OMPT region types */
typedef enum ompt_region_type
{
    OMPT_REGION_TYPES
        OMPT_INVALID_REGION_TYPE
}ompt_region_type;

#undef OMPT_REGION_TYPE

/* *INDENT-OFF* */
#define SCOREP_OMPT_REGIONS                                      \
  SCOREP_OMPT_REGION( parallel,       SCOREP_REGION_PARALLEL )   \
  SCOREP_OMPT_REGION( task,           SCOREP_REGION_TASK )       \
  SCOREP_OMPT_REGION( target,         SCOREP_REGION_CODE )       \
  SCOREP_OMPT_REGION( implicit_task,  SCOREP_REGION_PARALLEL )   \
  SCOREP_OMPT_REGION( loop,           SCOREP_REGION_LOOP )       \
  SCOREP_OMPT_REGION( section,        SCOREP_REGION_SECTIONS )   \
  SCOREP_OMPT_REGION( single,         SCOREP_REGION_SINGLE )     \
  SCOREP_OMPT_REGION( master,         SCOREP_REGION_MASTER )     \
  SCOREP_OMPT_REGION( barrier,        SCOREP_REGION_BARRIER )    \
  SCOREP_OMPT_REGION( taskwait,       SCOREP_REGION_TASK_WAIT )  \
  SCOREP_OMPT_REGION( taskgroup,      SCOREP_REGION_TASK_WAIT )  \
  SCOREP_OMPT_REGION( atomic,         SCOREP_REGION_ATOMIC )     \
  SCOREP_OMPT_REGION( ordered,        SCOREP_REGION_ORDERED )    \
  SCOREP_OMPT_REGION( wait_barrier,   SCOREP_REGION_ARTIFICIAL ) \
  SCOREP_OMPT_REGION( wait_taskwait,  SCOREP_REGION_TASK_WAIT )  \
  SCOREP_OMPT_REGION( wait_taskgroup, SCOREP_REGION_TASK_WAIT)   \
  SCOREP_OMPT_REGION( wait_lock,      SCOREP_REGION_CRITICAL )   \
  SCOREP_OMPT_REGION( wait_nest_lock, SCOREP_REGION_CRITICAL )   \
  SCOREP_OMPT_REGION( wait_critical,  SCOREP_REGION_CRITICAL )   \
  SCOREP_OMPT_REGION( wait_atomic,    SCOREP_REGION_ATOMIC )     \
  SCOREP_OMPT_REGION( wait_ordered,   SCOREP_REGION_ORDERED )    \
  SCOREP_OMPT_REGION( idle,           SCOREP_REGION_ARTIFICIAL )
/* *INDENT-ON* */

/**
 * Mapping of Score-P region handles, POMP2 region types
 */
typedef struct
{
    SCOREP_RegionHandle handle;
    POMP2_Region_type   type;
    unsigned            id;
}scorep_ompt_region_t;

//typedef scorep_ompt_region_t*  POMP2_Region_handle;

#define SCOREP_INVALID_REGION_ID -1

/**
 * Score-P OMPT region type.
 */
typedef struct ompt_region_t
{
    SCOREP_RegionHandle   handle;
    SCOREP_RegionType     type;
    void*                 func;  /**< function pointer is the key */
    struct ompt_region_t* next;  /**< next entry in bucket */
    struct ompt_region_t* prev;  /**< previous entry in stack */
}ompt_region_t;

/**
 * Structure for a stack of Score-P region handles.
 */
typedef struct region_stack_element
{
    SCOREP_RegionHandle          handle; /**< Score-P region handle */
    struct region_stack_element* next;   /**< next element in stack */
    struct region_stack_element* prev;   /**< previous entry in stack */
}region_stack_element;

/**
 * Structure for a stack of Score-P region handles.
 */
typedef struct map_element
{
    ompt_data_map_id_t  data_map_id; /**< OMPT target data mapping ID */
    ompt_data_map_t     map_type;    /**< type of the data mapping / motion */
    bool                empty;       /**< Is this entry used or empty? */
    struct map_element* next;        /**< next element in list */
}map_element;

/**
 * Location data for the OMPT adapter.
 */
typedef struct scorep_ompt_location_data
{
    void*                 curr_target_device; /**< current target device */
    bool                  in_callback;        /**< Is this thread in a callback? */
    size_t                stack_depth;        /**< current stack depth */
    size_t                stack_depth_max;    /**< maximum allocated stack depth */
    region_stack_element* region_stack;       /**< pointer to top of OMPT region stack */
    map_element*          map_list;           /**< pointer to OMPT target data map list */
} scorep_ompt_location_data;


/** ID of the OMPT subsystem */
extern size_t scorep_ompt_subsystem_id;

void
scorep_ompt_regions_init();

/**
 * Returns the region structure for the OPARI/POMP region with the given ID.
 *
 * @param id OPARI2 generated region ID
 *
 * @return region structure
 */
scorep_ompt_region_t*
scorep_ompt_regions_get( size_t id );

/**
 * Returns the region handle for the OPARI/POMP region with the given id
 * Throws an exception if region does not exist
 *
 * @param id OPARI2 generated region ID
 *
 * @return Score-P region handle
 */
SCOREP_RegionHandle
scorep_ompt_regions_getHandle( size_t id );

/**
 * Returns the Score-P region handle for
 *
 * @param type OMPT region type
 * @param func pointer to the outlined function (address)
 *
 * @return Score-P region handle
 */
SCOREP_RegionHandle
scorep_ompt_region_get( ompt_region_type type,
                        void*            func );

/**
 * Initialize the OMPT region stack.
 *
 * @param location the Score-P location
 *
 * @return the locations OMPT subsystem data
 */
scorep_ompt_location_data*
ompt_region_location_init( SCOREP_Location* location );

/**
 * Put a Score-P region on the top of the subsystems location stack.
 *
 * @param region Score-P region handle
 */
void
ompt_region_push( SCOREP_RegionHandle region );

/**
 * Pop a Score-P region from the top of the subsystems location stack.
 *
 * @return Score-P region handle
 */
SCOREP_RegionHandle
ompt_region_pop( void );

/**
 * Put an OMPT data mapping type on the top of the subsystems location stack.
 *
 * @param mapType OMPT data mapping type
 */
void
ompt_map_push( ompt_data_map_id_t mapId,
               ompt_data_map_t    mapType );

/**
 * Pop an OMPT data mapping type from the top of the subsystems location stack.
 *
 * @return OMPT data mapping type
 */
ompt_data_map_t
ompt_map_pop( ompt_data_map_id_t mapId );

#endif  /* SCOREP_OMPT_REGIONS_H */

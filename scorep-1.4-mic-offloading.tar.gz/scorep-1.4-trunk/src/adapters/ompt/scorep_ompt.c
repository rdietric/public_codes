/*
 * This file is part of the Score-P software (http://www.score-p.org)
 *
 * Copyright (c) 2014, 2015
 * Technische Universitaet Dresden, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license. See the COPYING file in the package base
 * directory for details.
 *
 */

/**
 *  @file
 *
 *  Implementation of the OMPT interace
 */

#include <config.h>

#include <omp.h>

#include <stdbool.h>
#include <string.h>

#include <SCOREP_RuntimeManagement.h>
#include <SCOREP_Events.h>
#include <SCOREP_Memory.h>
#include <SCOREP_ThreadForkJoin_Event.h>
#include <SCOREP_Properties.h>
#include <SCOREP_Definitions.h>
#include <SCOREP_Types.h>
#include <SCOREP_Timing.h>

#include <UTILS_Error.h>
#define SCOREP_DEBUG_MODULE_NAME OMPT
#include <UTILS_Debug.h>

#include "SCOREP_Ompt_Tpd.h"
#include "scorep_ompt.h"
#include "SCOREP_Ompt_Regions.h"
#include <SCOREP_Omp_Target.h>
#include <SCOREP_Omp_Target_Events.h>
#include <opari2/mpti_lib.h>

#define OUTPUT_DEBUG 0

#define OMPT_API_DECLARE( fn ) static fn ## _t fn = NULL;

#define LOOKUP( lookup, fn ) fn = ( fn ## _t )lookup( #fn ); \
    if ( !fn ) \
    { \
        UTILS_WARNING( "Could not lookup function %s!\n", #fn ); \
        return 0; \
    }

#define CHECK( EVENT ) \
    if ( ompt_set_callback( EVENT, ( ompt_callback_t )scorep_##EVENT ) != ompt_set_result_event_may_occur_callback_always ) \
    { \
        UTILS_BUG( "Failed to register OMPT callback %s!\n", #EVENT ); \
    }

// internal debugging output
#if OUTPUT_DEBUG
#define PRINT( msg ) fprintf( stderr, msg ); fflush( stderr )
#define DEBUG( format, ... ) fprintf( stderr, format, __VA_ARGS__ ); fflush( stderr )
#else
#define PRINT( msg )
#define DEBUG( format, ... )
#endif

/* String constants for attribute references */
#define SCOREP_OMPT_TID_KEY                "OMPT_THREAD_ID"
#define SCOREP_OMPT_PARALLEL_REGION_ID_KEY "OMPT_PARALLEL_REGION_ID"

// internal function declarations
static void
ompt_set_features( void );

/* Declaration of OMPT functions */
FOREACH_OMPT_FN( OMPT_API_DECLARE )

// variable declarations
static bool scorep_ompt_initialized = false;
static bool scorep_ompt_finalized = false;

/* Define region handles for ompt regions */
#define SCOREP_OMPT_REGION( region, type )                              \
    static SCOREP_RegionHandle scorep_ ## region ## _region_handle = SCOREP_INVALID_REGION;
SCOREP_OMPT_REGIONS
#undef SCOREP_OMPT_REGION

SCOREP_AttributeHandle scorep_ompt_tid_attr;
SCOREP_AttributeHandle scorep_ompt_parallel_id_attr;

/** Workaround for initial_thread_begin coming before adapter is initialized*/
static ompt_thread_id_t ompt_initial_thread_id = 0;


/******************************************************************************/


void
scorep_ompt_event_parallel_begin(
    ompt_task_id_t     parent_task_id,      /* tool data for parent task   */
    ompt_frame_t*      parent_task_frame,   /* frame data of parent task   */
    ompt_parallel_id_t parallel_id,         /* id of parallel region       */
    uint32_t           requested_team_size, /* requested number of threads */
    void*              parallel_function )  /* outlined function           */
{
    DEBUG( "OMPT PARALLEL ENTER thread ID %d\n", ( int )ompt_get_thread_id() );

    SCOREP_AddAttribute( scorep_ompt_parallel_id_attr, &parallel_id );

#ifdef OPARI
    scorep_ompt_tpd_t* tpd = SCOREP_Ompt_Tpd_Get( ompt_get_thread_id() );
    UTILS_BUG_ON( tpd->currentStackLevel < 0, "Opari source code information is missing!" );

    SCOREP_EnterRegion( scorep_ompt_regions_getHandle( tpd->regionStack[ tpd->currentStackLevel ] ) );
#else
    SCOREP_RegionHandle region =
        scorep_ompt_region_get( OMPT_REGION_PARALLEL, parallel_function );

    ompt_region_push( region );

    SCOREP_EnterRegion( region );
#endif

    SCOREP_ThreadForkJoin_Fork( SCOREP_PARADIGM_OPENMP, requested_team_size );
}

void
scorep_ompt_event_parallel_end(
    ompt_parallel_id_t parallel_id, /* id of parallel region       */
    ompt_task_id_t     task_id )    /* id for task                 */
{
    DEBUG( "OMPT PARALLEL END %d\n", ( int )ompt_get_thread_id() );

#ifdef OPARI
    scorep_ompt_tpd_t* tpd = SCOREP_Ompt_Tpd_Get( ompt_get_thread_id() );
    UTILS_ASSERT( tpd->currentStackLevel >= 0 );

    SCOREP_ThreadForkJoin_Join( SCOREP_PARADIGM_OPENMP );

    SCOREP_ExitRegion( scorep_ompt_regions_getHandle( tpd->regionStack[ tpd->currentStackLevel ] ) );
#else
    SCOREP_ThreadForkJoin_Join( SCOREP_PARADIGM_OPENMP );

    SCOREP_ExitRegion( ompt_region_pop() );
#endif
}

void
scorep_ompt_event_thread_begin(
    ompt_thread_type_t thread_type, /* type of thread               */
    ompt_thread_id_t   thread_id    /* ID of thread                 */
    )
{
    //SCOREP_ThreadForkJoin_register_thread( thread_id, ompt_thread_in_parallel );
    DEBUG( "THREAD begin %d\n", thread_id );

    if ( !scorep_ompt_initialized && thread_type == ompt_thread_initial )
    {
        ompt_initial_thread_id = thread_id;
    }
    else
    {
        SCOREP_Ompt_Tpd_Add( thread_id );
    }
}

void
scorep_ompt_event_thread_end(
    ompt_thread_type_t thread_type, /* type of thread               */
    ompt_thread_id_t   thread_id    /* ID of thread                 */
    )
{
    //DEBUG( "OMPT THREAD END\n" );
    SCOREP_Ompt_Tpd_Remove( thread_id );
}

void
scorep_ompt_event_runtime_shutdown()
{
    scorep_ompt_finalize();
}

void
scorep_ompt_event_idle_begin(
    ompt_thread_id_t thread_id      /* ID of thread                 */
    )
{
    DEBUG( "scorep_ompt_idle_begin %d\n", thread_id );
    if ( SCOREP_ThreadForkJoin_LocationExists() )
    {
        //Thread already created
        SCOREP_EnterRegion( scorep_idle_region_handle );
    }
}

void
scorep_ompt_event_idle_end(
    ompt_thread_id_t thread_id      /* ID of thread                 */
    )
{
    PRINT( "scorep_ompt_idle_end\n" );
    if ( !scorep_ompt_finalized && SCOREP_ThreadForkJoin_LocationExists() )
    {
        //Thread already created
        SCOREP_ExitRegion( scorep_idle_region_handle );
    }
}

void
scorep_ompt_event_master_begin(
    ompt_parallel_id_t parallel_id, /* id of parallel region       */
    ompt_task_id_t     task_id )    /* id for task                 */
{
    SCOREP_EnterRegion( scorep_master_region_handle );
}

void
scorep_ompt_event_master_end(
    ompt_parallel_id_t parallel_id, /* id of parallel region       */
    ompt_task_id_t     task_id )    /* id for task                 */
{
    SCOREP_ExitRegion( scorep_master_region_handle );
}

void
scorep_ompt_event_barrier_begin(
    ompt_parallel_id_t parallel_id, /* id of parallel region       */
    ompt_task_id_t     task_id )    /* id for task                 */
{
    DEBUG( "scorep_ompt_barrier_begin %d\n", ompt_get_thread_id() );
    SCOREP_AddAttribute( scorep_ompt_parallel_id_attr, &parallel_id );
    SCOREP_EnterRegion( scorep_barrier_region_handle );
}

void
scorep_ompt_event_barrier_end(
    ompt_parallel_id_t parallel_id, /* id of parallel region       */
    ompt_task_id_t     task_id )    /* id for task                 */
{
    DEBUG( "scorep_ompt_barrier_end %d\n", ompt_get_thread_id() );
    SCOREP_ExitRegion( scorep_barrier_region_handle );
}


void
scorep_ompt_event_loop_begin(
    ompt_parallel_id_t parallel_id, /* id of parallel region       */
    ompt_task_id_t     task_id )    /* id for task  */
{
    scorep_ompt_tpd_t*  tpd          = SCOREP_Ompt_Tpd_Get( ompt_get_thread_id() );
    SCOREP_RegionHandle regionHandle = scorep_loop_region_handle;

    //Check if we know, in which loop we are (only applies if we have an explicit omp loop)
    //TODO: Will NOT work (false positive) with e.g. "#omp parallel; #omp loop; #omp parallel loop"
    //Current solution: Use invalid region id in implicit task begin
    if ( tpd->currentStackLevel >= 0 )
    {
        uint64_t regionId = tpd->regionStack[ tpd->currentStackLevel ];
        if ( regionId != SCOREP_INVALID_REGION_ID )
        {
            scorep_ompt_region_t* region = scorep_ompt_regions_get( regionId );
            UTILS_BUG_ON( region == NULL, "Unknown region id %d", regionId );
            if ( region->type == POMP2_Do || region->type == POMP2_For )
            {
                regionHandle = region->handle;
            }
        }
    }

    SCOREP_AddAttribute( scorep_ompt_parallel_id_attr, &parallel_id );
    SCOREP_EnterRegion( regionHandle );
}

void
scorep_ompt_event_loop_end(
    ompt_parallel_id_t parallel_id, /* id of parallel region       */
    ompt_task_id_t     task_id )    /* id for task  */
{
    scorep_ompt_tpd_t*  tpd          = SCOREP_Ompt_Tpd_Get( ompt_get_thread_id() );
    SCOREP_RegionHandle regionHandle = scorep_loop_region_handle;

    if ( tpd->currentStackLevel >= 0 )
    {
        uint64_t regionId = tpd->regionStack[ tpd->currentStackLevel ];
        if ( regionId != SCOREP_INVALID_REGION_ID )
        {
            scorep_ompt_region_t* region = scorep_ompt_regions_get( regionId );
            UTILS_BUG_ON( region == NULL, "Unknown region id %d", regionId );
            if ( region->type == POMP2_Do || region->type == POMP2_For )
            {
                regionHandle = region->handle;
            }
        }
    }

    SCOREP_ExitRegion( regionHandle );
}

void
scorep_ompt_event_task_begin(
    ompt_task_id_t parent_task_id,     /* ID of parent task */
    ompt_frame_t*  parent_task_frame,  /* frame data for parent task */
    ompt_task_id_t new_task_id,        /* ID of created task */
    void*          new_task_function ) /* pointer to outlined function */
{
    scorep_ompt_tpd_t* tpd = SCOREP_Ompt_Tpd_Get( ompt_get_thread_id() );
    tpd->taskEnterTimestamp  = SCOREP_GetClockTicks();
    tpd->currentTaskRegionId = SCOREP_INVALID_REGION_ID;
}

void
scorep_ompt_event_task_end(
    ompt_task_id_t task_id )
{
    scorep_ompt_tpd_t* tpd = SCOREP_Ompt_Tpd_Get( ompt_get_thread_id() );
    UTILS_BUG_ON( tpd->currentTaskRegionId == SCOREP_INVALID_REGION_ID, "Instrumentation for tasks is missing!" );
    SCOREP_ExitRegion( scorep_ompt_regions_getHandle( tpd->currentTaskRegionId ) );
}

void
scorep_ompt_event_target_begin(
    ompt_task_id_t          task_id,          /* ID of task */
    ompt_target_id_t        target_id,        /* ID of target* region */
    ompt_target_device_id_t device_id,        /* ID of the device */
    void*                   target_function ) /* pointer to outlined function */
{
    SCOREP_Location* location = SCOREP_Location_GetCurrentCPULocation();

    scorep_ompt_location_data* loc_data =
        SCOREP_Location_GetSubsystemData( location,
                                          scorep_ompt_subsystem_id );

    if ( NULL == loc_data )
    {
        loc_data = ompt_region_location_init( location );
    }

    // don't process callbacks triggered by measurement (prevent infinite loop)
    if ( loc_data->in_callback )
    {
        return;
    }

    UTILS_DEBUG_ENTRY( "[OMPT] target_id: %d, task_id: %d,  device = %d",
                       target_id, task_id, device_id );

    loc_data->in_callback = true;

    if ( ( scorep_ompt_features & SCOREP_OMPT_FEATURE_DEVICE )
         && !scorep_ompcommon_is_finalized )
    {
        if ( !scorep_omp_target.transferBuffer )
        {
            scorep_omp_target.transferBuffer = ( mpti_record_t* )SCOREP_Memory_AllocForMisc(
                sizeof( mpti_record_t ) * SCOREP_OMP_TARGET_BUFFER_SIZE );
        }

        omp_target_measure_overhead( &scorep_omp_target.measuredInitialOverhead, device_id );

        SCOREP_Omp_Target_Device* dev = scorep_omp_target_getcreate_device( device_id );
        loc_data->curr_target_device = ( void* )dev;

        // create a synchronization point before the target region
        uint64_t deviceStartTime = 0;
#pragma omp target map(from:deviceStartTime) device(device_id)
        deviceStartTime = omp_get_wtime() / omp_get_wtick();

        dev->hostStartTime   = SCOREP_GetClockTicks();
        dev->hostEndTime     = 0;
        dev->deviceStartTime = deviceStartTime;

#ifdef OPARI
        // create window on every host location, where it is used
        scorep_omp_target_create_rma_window();

        // create RDMA location (if necessary)
        scorep_omp_target_create_rdma_location( dev );

        SCOREP_RmaPut(
            scorep_omp_target.interim_window_handle,
            dev->rmaId,
            0, 42 + dev->id );
#endif
    }

    //TODO: if source code information are available (see addr2line.c)
    SCOREP_RegionHandle region = scorep_ompt_region_get( OMPT_REGION_TARGET, target_function );

    ompt_region_push( region );
    SCOREP_EnterRegion( region );

    loc_data->in_callback = false;
}

void
scorep_ompt_event_target_end(
    ompt_task_id_t   task_id,         /* ID of task */
    ompt_target_id_t target_id )      /* ID of target* region */
{
    scorep_ompt_location_data* loc_data =
        SCOREP_Location_GetSubsystemData( SCOREP_Location_GetCurrentCPULocation(),
                                          scorep_ompt_subsystem_id );

    // don't process callbacks triggered by measurement system
    if ( loc_data == NULL || loc_data->in_callback )
    {
        return;
    }

    if ( scorep_ompt_features & SCOREP_OMPT_FEATURE_DEVICE )
    {
        loc_data->in_callback = true;

        SCOREP_Omp_Target_Device* dev =
            ( SCOREP_Omp_Target_Device* )loc_data->curr_target_device;

        UTILS_DEBUG_ENTRY( "[OMPT] device = %d", dev->id );

        if ( !scorep_ompcommon_is_finalized )
        {
            uint64_t deviceEndTime = 0;

#pragma omp target map(from:deviceEndTime) device(dev->id)
            deviceEndTime = omp_get_wtime() / omp_get_wtick();

            dev->hostEndTime = SCOREP_GetClockTicks();

            // check for valid timestamps and compute time synchronization ratio
            if ( dev->hostEndTime > dev->hostStartTime )
            {
                if ( deviceEndTime > dev->deviceStartTime )
                {
                    dev->targetHostSyncRatio =
                        ( double )( dev->hostEndTime - dev->hostStartTime ) /
                        ( double )( deviceEndTime - dev->deviceStartTime );
                }
                else
                {
                    UTILS_WARNING( "OMP target region time (device) <= 0" );
                }
            }
            else
            {
                UTILS_WARNING( "OMP target region time (host) <= 0" );
            }

            SCOREP_Omp_Common_offload_flush( SCOREP_INVALID_REGION, dev->id );
        }

        loc_data->in_callback = false;
    }
    else
    {
        UTILS_DEBUG_ENTRY( "[OMPT] target ID: %d", ( int )target_id );
    }

    SCOREP_ExitRegion( ompt_region_pop() );
}


void
scorep_ompt_event_target_data_begin(
    ompt_task_id_t          task_id,          /* ID of task */
    ompt_target_id_t        target_id,        /* ID of target* region */
    ompt_target_device_id_t device_id,        /* ID of the device */
    void*                   target_function ) /* pointer to outlined function */
{
    SCOREP_Location* location = SCOREP_Location_GetCurrentCPULocation();

    scorep_ompt_location_data* loc_data =
        SCOREP_Location_GetSubsystemData( location,
                                          scorep_ompt_subsystem_id );

    if ( NULL == loc_data )
    {
        loc_data = ompt_region_location_init( location );
    }

    // don't process callbacks triggered by measurement (prevent infinite loop)
    if ( loc_data->in_callback )
    {
        return;
    }

    UTILS_DEBUG_ENTRY( "[OMPT] target ID: %d (device %d)", target_id, device_id );

    if ( !scorep_ompcommon_is_initialized && !scorep_ompcommon_is_finalized )
    {
        SCOREP_Omp_Target_Init();
    }

    loc_data->in_callback = true;

    omp_target_measure_overhead( &scorep_omp_target.measuredInitialOverhead,
                                 device_id );

    loc_data->in_callback = false;

    SCOREP_RegionHandle region = scorep_ompt_region_get( OMPT_REGION_TARGET_DATA, target_function );

    ompt_region_push( region );
    SCOREP_EnterRegion( region );
}

void
scorep_ompt_event_target_data_end(
    ompt_task_id_t   task_id,         /* ID of task */
    ompt_target_id_t target_id )      /* ID of target* region */
{
    scorep_ompt_location_data* loc_data =
        SCOREP_Location_GetSubsystemData( SCOREP_Location_GetCurrentCPULocation(),
                                          scorep_ompt_subsystem_id );

    // don't process callbacks triggered by measurement system
    if ( loc_data == NULL || loc_data->in_callback )
    {
        return;
    }

    UTILS_DEBUG_ENTRY( "[OMPT] target ID: %d", target_id );

    SCOREP_ExitRegion( ompt_region_pop() );
}

void
scorep_ompt_event_target_update_begin(
    ompt_task_id_t          task_id,          /* ID of task */
    ompt_target_id_t        target_id,        /* ID of target* region */
    ompt_target_device_id_t device_id,        /* ID of the device */
    void*                   target_function ) /* pointer to outlined function */
{
    SCOREP_Location* location = SCOREP_Location_GetCurrentCPULocation();

    scorep_ompt_location_data* loc_data =
        SCOREP_Location_GetSubsystemData( location,
                                          scorep_ompt_subsystem_id );

    if ( NULL == loc_data )
    {
        loc_data = ompt_region_location_init( location );
    }

    if ( loc_data->in_callback )
    {
        return;
    }

    loc_data->in_callback = true;

    if ( !scorep_ompcommon_is_initialized && !scorep_ompcommon_is_finalized )
    {
        SCOREP_Omp_Target_Init();
    }

    UTILS_DEBUG_ENTRY( "[OMPT] target ID: %d (device %d)", target_id, device_id );

    omp_target_measure_overhead( &scorep_omp_target.measuredInitialOverhead,
                                 device_id );

    SCOREP_RegionHandle region = scorep_ompt_region_get( OMPT_REGION_TARGET_UPDATE, target_function );

    ompt_region_push( region );
    SCOREP_EnterRegion( region );

    loc_data->in_callback = false;
}

void
scorep_ompt_event_target_update_end(
    ompt_task_id_t   task_id,         /* ID of task */
    ompt_target_id_t target_id )      /* ID of target* region */
{
    scorep_ompt_location_data* loc_data =
        SCOREP_Location_GetSubsystemData( SCOREP_Location_GetCurrentCPULocation(),
                                          scorep_ompt_subsystem_id );

    // don't process callbacks triggered by measurement system
    if ( loc_data == NULL || loc_data->in_callback )
    {
        return;
    }

    UTILS_DEBUG_ENTRY( "[OMPT] target ID: %d", target_id );

    SCOREP_ExitRegion( ompt_region_pop() );
}

void
scorep_ompt_event_target_invoke_begin(
    ompt_task_id_t          task_id,          /* ID of task */
    ompt_target_id_t        target_id,        /* ID of target* region */
    ompt_target_device_id_t device_id,        /* ID of the device */
    void*                   target_function ) /* pointer to outlined function */
{
    scorep_ompt_location_data* loc_data =
        SCOREP_Location_GetSubsystemData( SCOREP_Location_GetCurrentCPULocation(),
                                          scorep_ompt_subsystem_id );

    // don't process callbacks triggered by measurement system
    if ( loc_data == NULL || loc_data->in_callback )
    {
        return;
    }

    UTILS_DEBUG_ENTRY( "[OMPT] target ID: %d (device %d)", target_id, device_id );

    SCOREP_RegionHandle region = scorep_ompt_region_get( OMPT_REGION_TARGET_INVOKE, target_function );

    ompt_region_push( region );
    SCOREP_EnterRegion( region );
}

void
scorep_ompt_event_target_invoke_end(
    ompt_task_id_t   task_id,         /* ID of task */
    ompt_target_id_t target_id )      /* ID of target* region */
{
    scorep_ompt_location_data* loc_data =
        SCOREP_Location_GetSubsystemData( SCOREP_Location_GetCurrentCPULocation(),
                                          scorep_ompt_subsystem_id );

    // don't process callbacks triggered by measurement system
    if ( loc_data == NULL || loc_data->in_callback )
    {
        return;
    }

    UTILS_DEBUG_ENTRY( "[OMPT] target ID: %d", target_id );

    SCOREP_ExitRegion( ompt_region_pop() );
}

void
scorep_ompt_event_data_map_begin(
    ompt_task_id_t          task_id,                    /* ID of task */
    ompt_target_id_t        target_id,                  /* ID of target* region */
    ompt_data_map_id_t      data_map_id,                /* ID of data map operation */
    ompt_target_device_id_t device_id,                  /* ID of the device */
    ompt_target_sync_t      sync_type,                  /* sync or asynchronous data map      */
    ompt_data_map_t         map_type,                   /* type of the data mapping / motion */
    uint64_t                bytes                     ) /* amount of mapped bytes */
{
    if ( scorep_ompcommon_is_initialized && !scorep_ompcommon_is_finalized )
    {
        SCOREP_Location* location = SCOREP_Location_GetCurrentCPULocation();

        scorep_ompt_location_data* loc_data =
            SCOREP_Location_GetSubsystemData( location,
                                              scorep_ompt_subsystem_id );

        if ( NULL == loc_data )
        {
            loc_data = ompt_region_location_init( location );
        }

        if ( loc_data->in_callback )
        {
            return;
        }

        loc_data->in_callback = true;

        UTILS_DEBUG_ENTRY( "[OMPT] target ID: %d, map ID: %llu (device %d)",
                           target_id, data_map_id, device_id );

        SCOREP_Omp_Target_Device* dev = scorep_omp_target_getcreate_device( device_id );

        loc_data->curr_target_device = ( void* )dev;

        // create window on every host location, where it is used
        scorep_omp_target_create_rma_window();

        // create RDMA location (if necessary)
        scorep_omp_target_create_rdma_location( dev );

        // measure overhead only if H2D transfer as first operation
        if ( ompt_data_map_IN == map_type )
        {
            omp_target_measure_overhead( &scorep_omp_target.measuredInitialOverhead,
                                         device_id );
        }

        UTILS_DEBUG_ENTRY( "[OMPT] map type: %d ", map_type );

        uint64_t timestamp = SCOREP_GetClockTicks();
        SCOREP_Location_SetLastTimestamp( location, timestamp );

        // add RDMA operation
        if ( ompt_data_map_IN == map_type )
        {
            // h2d
            SCOREP_Location_RmaPut( location, timestamp,
                                    scorep_omp_target.interim_window_handle,
                                    dev->rmaId,
                                    bytes, 42 + device_id );
        }
        else if ( ompt_data_map_OUT == map_type )
        {
            // d2h
            SCOREP_Location_RmaGet( location, timestamp,
                                    scorep_omp_target.interim_window_handle,
                                    dev->rmaId,
                                    bytes, 42 + device_id );
        }
        else if ( ompt_data_map_INOUT == map_type )
        {
            // h2d
            SCOREP_Location_RmaPut( location, timestamp,
                                    scorep_omp_target.interim_window_handle,
                                    dev->rmaId,
                                    bytes, 42 + device_id );

            // d2h
            SCOREP_Location_RmaGet( location, timestamp,
                                    scorep_omp_target.interim_window_handle,
                                    dev->rmaId,
                                    bytes, 42 + device_id );
        }
        ompt_map_push( data_map_id, map_type );

        loc_data->in_callback = false;
    }
}

void
scorep_ompt_event_data_map_end(
    ompt_task_id_t     task_id,      /* ID of task */
    ompt_target_id_t   target_id,    /* ID of target* region */
    ompt_data_map_id_t data_map_id ) /* ID of data map operation */
{
    if ( !scorep_ompcommon_is_finalized )
    {
        SCOREP_Location* location = SCOREP_Location_GetCurrentCPULocation();

        scorep_ompt_location_data* loc_data =
            SCOREP_Location_GetSubsystemData( location,
                                              scorep_ompt_subsystem_id );

        // don't process callbacks triggered by measurement system
        if ( loc_data == NULL || loc_data->in_callback )
        {
            return;
        }

        UTILS_DEBUG_ENTRY( "[OMPT] target ID: %d, map ID %llu ", target_id, data_map_id );

        SCOREP_Omp_Target_Device* dev =
            ( SCOREP_Omp_Target_Device* )loc_data->curr_target_device;

        // add RDMA complete
        ompt_data_map_t map_type = ompt_map_pop( data_map_id );
        UTILS_DEBUG_ENTRY( "[OMPT] map type: %d ", map_type );

        if ( SCOREP_INVALID_OMP_TARGET_ID != dev->rmaId )
        {
            uint64_t timestamp = SCOREP_GetClockTicks();
            SCOREP_Location_SetLastTimestamp( location, timestamp );

            SCOREP_Location_RmaOpCompleteBlocking( location,
                                                   timestamp,
                                                   scorep_omp_target.interim_window_handle,
                                                   42 + dev->id );

            if ( ompt_data_map_INOUT == map_type )
            {
                SCOREP_Location_RmaOpCompleteBlocking( location,
                                                       timestamp,
                                                       scorep_omp_target.interim_window_handle,
                                                       42 + dev->id );
            }
        }
    }
}

void
scorep_ompt_event_control(
    uint64_t command,            /* command of control call      */
    uint64_t modifier )          /* modifier of control call     */
{
    UTILS_DEBUG_ENTRY( "[OMPT] event control( %llu, %llu )", command, modifier );

    scorep_ompt_tpd_t* tpd;
    switch ( command )
    {
        case OMPT_COMMAND_START:
        case OMPT_COMMAND_PAUSE:
        case OMPT_COMMAND_STOP:
        case OMPT_COMMAND_GET_NUM_RECORDS:
        case OMPT_COMMAND_FLUSH_RECORDS:
            UTILS_DEBUG( "Hint: OMPT_CONTROL command %llu::%llu ignored", command, modifier );
            break;

        case OMPT_COMMAND_PUSH_REGION_ID:
            tpd = SCOREP_Ompt_Tpd_Get( ompt_get_thread_id() );
            UTILS_BUG_ON( ++tpd->currentStackLevel >= SCOREP_OMPT_REGION_STACK_SIZE, "Maximum stack level of %d for OMPT regions reached.", SCOREP_OMPT_REGION_STACK_SIZE );
            tpd->regionStack[ tpd->currentStackLevel ] = modifier;
            break;

        case OMPT_COMMAND_POP_REGION_ID:
            tpd = SCOREP_Ompt_Tpd_Get( ompt_get_thread_id() );
            UTILS_BUG_ON( tpd->currentStackLevel < 0, "Unbalanced amount of push/pop of OMPT regions." );
            UTILS_BUG_ON( tpd->regionStack[ tpd->currentStackLevel-- ] != modifier, "Unexpected OMPT region in pop region." );
            break;

        case OMPT_COMMAND_TARGET_BEGIN:
        case OMPT_COMMAND_TARGET_END:
            UTILS_WARNING( "Hint: OMP 4.0 Target region executed on the host. This may not work yet!" );
            break;

        case OMPT_COMMAND_TASK_SET:
            tpd                      = SCOREP_Ompt_Tpd_Get( ompt_get_thread_id() );
            tpd->currentTaskRegionId = modifier;
            SCOREP_EnterRegion_With_Time( scorep_ompt_regions_getHandle( modifier ), tpd->taskEnterTimestamp );
            break;

        default:
            UTILS_ERROR( SCOREP_ERROR_EINVAL, "Unhandled OMPT command (%llu)\n", command );
    }
}

void
scorep_ompt_event_single_in_block_begin(
    ompt_parallel_id_t parallel_id,         /* id of parallel region        */
    ompt_task_id_t     task_id,             /* id for task                  */
    void*              workshare_function ) /* pointer to outlined function */
{
    //DEBUG( "%d: %s: par_id=0x%llx task_id=0x%llx\n", omp_get_thread_num(),  "ompt_event_single_in_block_begin", parallel_id, task_id );
}

void
scorep_ompt_event_single_in_block_end(
    ompt_parallel_id_t parallel_id, /* id of parallel region       */
    ompt_task_id_t     task_id )    /* id for task                 */
{
    //DEBUG( "%d: %s: par_id=0x%llx task_id=0x%llx\n", omp_get_thread_num(),  "ompt_event_single_in_block_end", parallel_id, task_id );
}

void
scorep_ompt_event_single_others_begin(
    ompt_parallel_id_t parallel_id, /* id of parallel region       */
    ompt_task_id_t     task_id )    /* id for task                 */
{
    //DEBUG( "%d: %s: par_id=0x%llx task_id=0x%llx\n", omp_get_thread_num(),  "ompt_event_single_others_begin", parallel_id, task_id );
}

void
scorep_ompt_event_single_others_end(
    ompt_parallel_id_t parallel_id, /* id of parallel region       */
    ompt_task_id_t     task_id )    /* id for task                 */
{
    //DEBUG( "%d: %s: par_id=0x%llx task_id=0x%llx\n", omp_get_thread_num(),  "ompt_event_single_others_end", parallel_id, task_id );
}

void
scorep_ompt_event_release_lock(
    ompt_wait_id_t waitid )         /* address of wait obj */
{
    //DEBUG( "%d: %s: waid_id=0x%llx\n", omp_get_thread_num(), "ompt_event_release_lock", waitid );
}

void
scorep_ompt_event_release_critical(
    ompt_wait_id_t waitid )         /* address of wait obj */
{
    //DEBUG( "%d: %s: waid_id=0x%llx\n", omp_get_thread_num(), "ompt_event_release_critical", waitid );
}

void
scorep_ompt_event_release_atomic(
    ompt_wait_id_t waitid )         /* address of wait obj */
{
    //DEBUG( "%d: %s: waid_id=0x%llx\n", omp_get_thread_num(), "ompt_event_release_atomic", waitid );
}

void
scorep_ompt_event_release_ordered(
    ompt_wait_id_t waitid )         /* address of wait obj */
{
    //DEBUG( "%d: %s: waid_id=0x%llx\n", omp_get_thread_num(), "ompt_event_release_ordered", waitid );
}

void
scorep_ompt_event_wait_atomic(
    ompt_wait_id_t waitid )         /* address of wait obj */
{
    //DEBUG( "%d: %s: waid_id=0x%llx\n", omp_get_thread_num(), "ompt_event_wait_atomic", waitid );
}

void
scorep_ompt_event_acquired_atomic(
    ompt_wait_id_t waitid )         /* address of wait obj */
{
    //DEBUG( "%d: %s: waid_id=0x%llx\n", omp_get_thread_num(), "ompt_event_acquired_atomic", waitid );
}

void
scorep_ompt_event_implicit_task_begin(
    ompt_parallel_id_t parallel_id, /* id of parallel region       */
    ompt_task_id_t     task_id )    /* id for task                 */
{
    ompt_thread_id_t tid = ompt_get_thread_id();
    DEBUG( "scorep_ompt_implicit_task_begin %d\n", tid );

    SCOREP_ThreadForkJoin_TeamBegin( SCOREP_PARADIGM_OPENMP, tid );

    SCOREP_AddAttribute( scorep_ompt_tid_attr, &tid );
    SCOREP_EnterRegion( scorep_implicit_task_region_handle );
    // "Clear" current region
    scorep_ompt_event_control( OMPT_COMMAND_PUSH_REGION_ID, SCOREP_INVALID_REGION_ID );
}

void
scorep_ompt_event_implicit_task_end(
    ompt_parallel_id_t parallel_id, /* id of parallel region       */
    ompt_task_id_t     task_id )    /* id for task                 */
{
    PRINT( "scorep_ompt_implicit_task_end\n" );
    scorep_ompt_event_control( OMPT_COMMAND_POP_REGION_ID, SCOREP_INVALID_REGION_ID );
    SCOREP_ExitRegion( scorep_implicit_task_region_handle );

    SCOREP_ThreadForkJoin_TeamEnd( SCOREP_PARADIGM_OPENMP );
}

void
scorep_ompt_event_wait_barrier_begin(
    ompt_parallel_id_t parallel_id, /* id of parallel region       */
    ompt_task_id_t     task_id )    /* id for task                 */
{
    PRINT( "scorep_ompt_wait_barrier_begin\n" );
    SCOREP_AddAttribute( scorep_ompt_parallel_id_attr, &parallel_id );
    SCOREP_EnterRegion( scorep_wait_barrier_region_handle );
}

void
scorep_ompt_event_wait_barrier_end(
    ompt_parallel_id_t parallel_id, /* id of parallel region       */
    ompt_task_id_t     task_id )    /* id for task                 */
{
    PRINT( "scorep_ompt_wait_barrier_end\n" );
    SCOREP_ExitRegion( scorep_wait_barrier_region_handle );
}

static bool
scorep_ompt_write_idle_end_cb( SCOREP_Location* location, void* data )
{
    //Master thread is not idling
    if ( location != data )
    {
        SCOREP_ExitRegion_For_Location( scorep_idle_region_handle, location );
    }
    return false;
}

/**
 * Gets called by scorep before the finalizing is done, so locations are still writable
 */
void
scorep_ompt_before_finalize()
{
    UTILS_DEBUG_ENTRY();
    if ( scorep_ompt_features & SCOREP_OMPT_FEATURE_IDLE )
    {
        SCOREP_Location_ForAll( scorep_ompt_write_idle_end_cb, SCOREP_Location_GetCurrentCPULocation() );
    }
}
/**
 * Initialize Score-P OMPT handling.
 */
void
scorep_ompt_finalize( void )
{
    UTILS_DEBUG_ENTRY();
    if ( scorep_ompt_initialized && !scorep_ompt_finalized )
    {
        scorep_ompt_finalized = true;

        SCOREP_Ompt_Tpd_Finalize();
    }
    return;
}

void
scorep_ompt_initialize( void )
{
    if ( !scorep_ompt_initialized )
    {
        UTILS_DEBUG_ENTRY();

        scorep_ompt_initialized = true;

        SCOREP_Ompt_Tpd_Init();
        scorep_ompt_regions_init();
        SCOREP_Omp_Target_Init();

        scorep_ompt_tid_attr = SCOREP_Definitions_NewAttribute(
            SCOREP_OMPT_TID_KEY, NULL, SCOREP_ATTRIBUTE_TYPE_UINT64 );

        scorep_ompt_parallel_id_attr = SCOREP_Definitions_NewAttribute(
            SCOREP_OMPT_PARALLEL_REGION_ID_KEY, NULL, SCOREP_ATTRIBUTE_TYPE_UINT64 );

        #define SCOREP_OMPT_REGION( region, type ) \
    scorep_ ## region ## _region_handle = \
        SCOREP_Definitions_NewRegion( "!$omp " #region, \
                                      NULL, SCOREP_INVALID_SOURCE_FILE, 0, 0, \
                                      SCOREP_PARADIGM_OPENMP, type );
        SCOREP_OMPT_REGIONS
        #undef SCOREP_OMPT_REGION

        /* Workaround for initial thread begin callback coming before adapter is initialized
           So just replay the event here */
        if ( ompt_initial_thread_id )
        {
            scorep_ompt_event_thread_begin( ompt_thread_initial, ompt_initial_thread_id );
            ompt_initial_thread_id = 0;
        }
    }
}

/**
 * This function is called from the OMPT implementation of the OpenMP library.
 */
int
ompt_initialize( ompt_function_lookup_t lookup,
                 const char*            runtime_version,
                 unsigned int           ompt_version )
{
    UTILS_DEBUG_ENTRY();

    /* This is required but causes the openmp runtime to initialize before this function returns
       and therefore missing the thread_begin for the initial thread.
       Adapter registration is triggered as well (evaluates SCOREP_OMPT_ENABLE) */
    SCOREP_InitMeasurement();

    // lookup functions
    #define macro( fn ) LOOKUP( lookup, fn )
    FOREACH_OMPT_FN( macro )
    #undef macro

    //CHECK( ompt_event_thread_begin );
    //CHECK( ompt_event_thread_end );

    UTILS_DEBUG( "Set OMPT features: %d", scorep_ompt_features );

    if ( scorep_ompt_features > 0 )
    {
        ompt_set_features();
    }

    // make sure the adapter is set up
    scorep_ompt_initialize();

    return 1;
}

static void
ompt_set_features()
{
    bool ompt_write_on_threads       = false;
    bool ompt_implicit_tasks_enabled = false;

    // check events if ompt_control() called by user application
    CHECK( ompt_event_control );

    // check for OMPT thread begin and end
    if ( !( scorep_ompt_features & SCOREP_OMPT_FEATURE_THREAD ) )
    {
        ompt_set_callback( ompt_event_thread_begin, NULL );
        ompt_set_callback( ompt_event_thread_end, NULL );
        //ompt_write_on_threads = true;
    }

    // check for OMPT parallel
    if ( scorep_ompt_features & SCOREP_OMPT_FEATURE_PARALLEL )
    {
        CHECK( ompt_event_parallel_begin );
        CHECK( ompt_event_parallel_end );
    }

    // check for OMPT loop
    if ( scorep_ompt_features & SCOREP_OMPT_FEATURE_LOOP )
    {
        CHECK( ompt_event_loop_begin );
        CHECK( ompt_event_loop_end );
        ompt_write_on_threads = true;
    }

    // check for OMPT barriers
    if ( scorep_ompt_features & SCOREP_OMPT_FEATURE_BARRIER )
    {
        CHECK( ompt_event_barrier_begin );
        CHECK( ompt_event_barrier_end );
        ompt_write_on_threads = true;
    }

    // check for OMPT tasks (explicit)
    if ( scorep_ompt_features & SCOREP_OMPT_FEATURE_TASK )
    {
        CHECK( ompt_event_task_begin );
        CHECK( ompt_event_task_end );
        //ompt_write_on_threads = true;
    }

    // check for OMPT waiting times in barriers
    if ( scorep_ompt_features & SCOREP_OMPT_FEATURE_WAIT_BARRIER )
    {
        CHECK( ompt_event_wait_barrier_begin );
        CHECK( ompt_event_wait_barrier_end );
        ompt_write_on_threads = true;
    }

    // check for OMPT implicit tasks (parallel region begin and end on threads)
    if ( scorep_ompt_features & SCOREP_OMPT_FEATURE_IMPLICIT_TASK )
    {
        CHECK( ompt_event_implicit_task_begin );
        CHECK( ompt_event_implicit_task_end );
        ompt_implicit_tasks_enabled = true;
    }

    // check for OMPT thread idle time
    if ( scorep_ompt_features & SCOREP_OMPT_FEATURE_IDLE )
    {
        CHECK( ompt_event_idle_begin );
        CHECK( ompt_event_idle_end );
        ompt_write_on_threads = true;
    }

    // check for OMPT shutdown routine
    if ( scorep_ompt_features & SCOREP_OMPT_FEATURE_SHUTDOWN )
    {
        CHECK( ompt_event_runtime_shutdown );
    }

    if ( ompt_write_on_threads && !ompt_implicit_tasks_enabled )
    {
        CHECK( ompt_event_implicit_task_begin );
        CHECK( ompt_event_implicit_task_end );
    }

    if ( scorep_ompt_features & SCOREP_OMPT_FEATURE_TARGET )
    {
        //UTILS_WARNING("[OMPT] Register target events");
        CHECK( ompt_event_target_begin );
        CHECK( ompt_event_target_end );

        CHECK( ompt_event_target_data_begin );
        CHECK( ompt_event_target_data_end );

        CHECK( ompt_event_data_map_begin );
        CHECK( ompt_event_data_map_end );

        CHECK( ompt_event_target_update_begin );
        CHECK( ompt_event_target_update_end );

        CHECK( ompt_event_target_invoke_begin );
        CHECK( ompt_event_target_invoke_end );
    }

    /* other optional events */
    // CHECK( ompt_event_release_lock );
    // CHECK( ompt_event_release_critical );
    // CHECK( ompt_event_release_atomic );
    // CHECK( ompt_event_release_ordered );

    //   /* optional events, synchronous */
    // CHECK( ompt_event_single_in_block_begin );
    // CHECK( ompt_event_single_in_block_end );
    // CHECK( ompt_event_single_others_begin );
    // CHECK( ompt_event_single_others_end );
    // CHECK( ompt_event_wait_atomic );
    // CHECK( ompt_event_acquired_atomic );
}

/* **************************************************************************************
 *                          Implementation of required functions for target handling
 ***************************************************************************************/

SCOREP_RegionHandle
SCOREP_Omp_Common_Target_Region_Get( uint64_t regionId, uint64_t regionType )
{
    return scorep_ompt_regions_getHandle( regionId );
    /*scorep_ompt_region_t* region = scorep_ompt_regions_get( regionId );
       if ( region )
       {
        return region->handle;
       }
       return SCOREP_INVALID_REGION;*/
}

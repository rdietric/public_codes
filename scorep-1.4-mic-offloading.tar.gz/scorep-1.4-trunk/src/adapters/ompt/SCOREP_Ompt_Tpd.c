/*
 * This file is part of the Score-P software (http://www.score-p.org)
 *
 * Copyright (c) 2014,
 * Technische Universitaet Dresden, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license. See the COPYING file in the package base
 * directory for details.
 *
 */

#include <config.h>
#include "SCOREP_Ompt_Tpd.h"
#include <omp.h>

#include <SCOREP_Mutex.h>
#include <SCOREP_Memory.h>

#include <UTILS_Debug.h>
#include <UTILS_Error.h>

typedef struct ompt_tpd_list_entry_t ompt_tpd_list_entry_t;

struct ompt_tpd_list_entry_t
{
    scorep_ompt_tpd_t      tpd;
    ompt_tpd_list_entry_t* next;
};

static bool                   ompt_tpd_valid = false;
static SCOREP_Mutex           ompt_lock;
static uint32_t               ompt_tpd_field_ct = 0;
static scorep_ompt_tpd_t*     ompt_tpd_field    = NULL;
static ompt_tpd_list_entry_t* ompt_tpd_list     = NULL;

void
SCOREP_Ompt_Tpd_Init()
{
    // allocate an array to store thread data
    ompt_tpd_field_ct = omp_get_max_threads();
    // Double it for nested regions
    ompt_tpd_field_ct *= 2;
    ompt_tpd_field     = ( scorep_ompt_tpd_t* )SCOREP_Memory_AllocForMisc( ompt_tpd_field_ct * sizeof( scorep_ompt_tpd_t ) );

    // create a mutex for OMPT handling
    SCOREP_MutexCreate( &ompt_lock );
    ompt_tpd_valid = true;
}

void
SCOREP_Ompt_Tpd_Finalize()
{
    ompt_tpd_valid = false;
    SCOREP_MutexDestroy( &ompt_lock );
}

scorep_ompt_tpd_t*
ompt_tpd_get( ompt_thread_id_t tid, bool assertExisting )
{
    scorep_ompt_tpd_t* result = ompt_tpd_field;
    uint32_t           ct     = 0;

    // Look for existing entry
    while ( ct < ompt_tpd_field_ct )
    {
        if ( result->tid == tid )
        {
            return result;
        }
        result++;
        ct++;
    }

    ompt_tpd_list_entry_t* tpdEntry = ompt_tpd_list;
    while ( tpdEntry )
    {
        if ( tpdEntry->tpd.tid == tid )
        {
            return &tpdEntry->tpd;
        }
        tpdEntry = tpdEntry->next;
    }

    UTILS_BUG_ON( assertExisting, "TPD for tid %u not found!", tid );

    return NULL;
}

scorep_ompt_tpd_t*
SCOREP_Ompt_Tpd_Get( ompt_thread_id_t tid )
{
    UTILS_ASSERT( tid );
    UTILS_BUG_ON( !ompt_tpd_valid, "TPD was already finalized when thread %u tried to get it", tid );
    return ompt_tpd_get( tid, true );
}

void
SCOREP_Ompt_Tpd_Add( ompt_thread_id_t tid )
{
    if ( !ompt_tpd_valid )
    {
        return;
    }
    //Create new data
    SCOREP_MutexLock( ompt_lock );
    //Find a free place in the field
    scorep_ompt_tpd_t* tpd = ompt_tpd_get( 0, false );

    if ( !tpd )
    {
        ompt_tpd_list_entry_t* tpdEntry = SCOREP_Memory_AllocForMisc( sizeof( ompt_tpd_list_entry_t ) );
        tpd            = &tpdEntry->tpd;
        tpdEntry->next = ompt_tpd_list;
        ompt_tpd_list  = tpdEntry;
    }

    //Init TPD
    tpd->tid               = tid;
    tpd->currentStackLevel = -1;

    SCOREP_MutexUnlock( ompt_lock );
}

void
SCOREP_Ompt_Tpd_Remove( ompt_thread_id_t tid )
{
    if ( !ompt_tpd_valid )
    {
        return;
    }
    scorep_ompt_tpd_t* tpd = ompt_tpd_get( tid, false );
    if ( tpd )
    {
        tpd->tid;
    }
}

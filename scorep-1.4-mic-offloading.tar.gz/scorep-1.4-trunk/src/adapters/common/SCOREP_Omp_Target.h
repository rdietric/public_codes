/*
 * This file is part of the Score-P software (http://www.score-p.org)
 *
 * Copyright (c) 2014,
 * Technische Universitaet Dresden, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license. See the COPYING file in the package base
 * directory for details.
 *
 */

#ifndef SCOREP_OMP_TARGET_H
#define SCOREP_OMP_TARGET_H

#include <SCOREP_RuntimeManagement.h>
#include <SCOREP_Types.h>
#include <SCOREP_Location.h>
#include <SCOREP_Definitions.h>
#define OMP_MPTI_REFERENCES 1
#include <opari2/mpti_lib.h>

typedef struct SCOREP_Omp_Target_Location
{
    uint64_t                           id;          /* thread id */
    uint32_t                           internalId;  /* internal location id */
    SCOREP_Location*                   location;    /* location handle */
#if ( OMP_MPTI_REFERENCES == 1 )
    uint64_t                           currentParallelRegionId[ 256 ];
    size_t                             currentStackLevel;
#endif
    struct SCOREP_Omp_Target_Location* next;       /* ptr to next entry */
}SCOREP_Omp_Target_Location;

typedef struct SCOREP_Omp_Target_Device
{
    int                              id;                    /* device id */
    uint64_t                         hostStartTime;         /* start time (host) of target region */
    uint64_t                         hostEndTime;           /* end time (host) of target region */
    uint64_t                         deviceStartTime;       /* start time (device/target) of target region */
    double                           targetHostSyncRatio;   /* current sync ratio for durations */
    SCOREP_Omp_Target_Location*      locations;             /* list mapping thread ids to locations */
    SCOREP_Location*                 rmaLocation;           /* location for data transfer records */
    uint32_t                         rmaId;                 /* internal device id */
    struct SCOREP_Omp_Target_Device* next;                  /* ptr to next entry */
}SCOREP_Omp_Target_Device;

typedef struct SCOREP_Omp_Target_RmaWindow
{
    SCOREP_Location*                    location;
    uint32_t                            internalId;
    struct SCOREP_Omp_Target_RmaWindow* next;
}SCOREP_Omp_Target_RmaWindow;

typedef struct SCOREP_Omp_Target_Info
{
    SCOREP_Omp_Target_Device*        devices;                  /* list of target devices */
    SCOREP_Omp_Target_RmaWindow*     rmaWindows;               /* list of RMA windows */
    SCOREP_SourceFileHandle          fileHandle;               /* target file handle */
    SCOREP_RegionHandle              barrierRegionHandle;      /* region handle for generic OMP barriers */
    SCOREP_RegionHandle              flushRegionHandle;        /* region handle for flushes */
    SCOREP_RegionHandle              overheadRegionHandle;     /* region handle for target start overhead */
    SCOREP_RegionHandle              implicitTaskRegionHandle; /* region handle for implicit tasks */
    uint8_t                          measuredInitialOverhead;  /* target overhead measured */
    mpti_record_t*                   transferBuffer;           /* buffer for target/host data transfers */
    uint32_t                         location_counter;         /* next location id (used internally) */
    size_t                           global_location_count;    /* number of global location ids */
    uint64_t*                        global_location_ids;
    /* handles for OMP target communication unification */
    SCOREP_InterimCommunicatorHandle interim_communicator_handle;
    SCOREP_InterimRmaWindowHandle    interim_window_handle;
}SCOREP_Omp_Target_Info;

extern SCOREP_Omp_Target_Info scorep_omp_target;

#if ( OMP_MPTI_REFERENCES == 1 )
extern SCOREP_AttributeHandle scorep_omp_target_location_ref_attr;
extern SCOREP_AttributeHandle scorep_omp_target_parent_location_ref_attr;
extern SCOREP_AttributeHandle scorep_omp_target_region_id_attr;
extern SCOREP_AttributeHandle scorep_omp_target_parent_region_id_attr;
#endif


SCOREP_Omp_Target_Device*
scorep_omp_target_getcreate_device( int id );

void
scorep_omp_target_create_rma_window( void );

void
scorep_omp_target_create_rdma_location( SCOREP_Omp_Target_Device* dev );

#define SCOREP_OMP_TARGET_BUFFER_SIZE ( 16384 )

#define SCOREP_INVALID_OMP_TARGET_ID 0xFFFFFFFF

#endif  /* SCOREP_OMP_TARGET_H */

/**
   @def SCOREP_OMP_ENSURE_INITIALIZED
    Initializes the measurement system if not done before
 */
#define SCOREP_OMP_ENSURE_INITIALIZED      \
    if ( !scorep_ompcommon_is_initialized )       \
    {                                        \
        SCOREP_InitMeasurement();                        \
    }

/** Flag to indicate whether the adapter is initialized */
extern bool scorep_ompcommon_is_initialized;

/** Flag to indicate whether the adapter is finalized */
extern bool scorep_ompcommon_is_finalized;

void
SCOREP_Omp_Target_Init();

/** Those 2 functions are implemented in measurement/paradigm/omp */
void
scorep_omp_define_target_locations( void );

void
scorep_omp_define_target_group( void );

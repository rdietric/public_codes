/*
 * File:   SCOREP_Target_Events.h
 * Author: alex
 *
 * Created on August 20, 2014, 6:16 PM
 */

#ifndef SCOREP_TARGET_EVENTS_H
#define SCOREP_TARGET_EVENTS_H

#include <SCOREP_Types.h>

#pragma omp declare target
double
omp_get_wtick( void );
double
omp_get_wtime( void );

void
ompt_control( uint64_t,
              uint64_t );
#pragma omp end declare target

void
omp_target_measure_overhead( uint8_t* measured,
                             int      deviceId );

/**
 * Maps a region id to the region handle
 * Callback function: MUST be implemented by the adapter!!!
 */
extern SCOREP_RegionHandle
SCOREP_Omp_Common_Target_Region_Get( uint64_t regionId,
                                     uint64_t regionType );

void
SCOREP_Omp_Target_begin( SCOREP_RegionHandle region,
                         int                 deviceId );

void
SCOREP_Omp_Target_end( SCOREP_RegionHandle region,
                       int                 deviceId );

void
SCOREP_Omp_Target_copy_begin( SCOREP_RegionHandle region,
                              uint8_t             direction,
                              int                 deviceId );

void
SCOREP_Omp_Target_copy_end( SCOREP_RegionHandle region,
                            uint8_t             direction,
                            int                 deviceId );

void
SCOREP_Omp_Target_flush( SCOREP_RegionHandle region,
                         int                 deviceId );

void
SCOREP_Omp_Target_update_begin( SCOREP_RegionHandle region,
                                uint8_t             direction,
                                int                 deviceId );

void
SCOREP_Omp_Target_update_end( SCOREP_RegionHandle region,
                              uint8_t             direction,
                              int                 deviceId );

void
SCOREP_Omp_Common_offload_flush( SCOREP_RegionHandle region,
                                 int                 deviceId );

#endif  /* SCOREP_TARGET_EVENTS_H */

/*
 * This file is part of the Score-P software (http://www.score-p.org)
 *
 * Copyright (c) 2014, 2015
 * Technische Universitaet Dresden, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license. See the COPYING file in the package base
 * directory for details.
 *
 */

#include <config.h>
#include <stddef.h>
#include <ompt.h>

#include <SCOREP_Events.h>
#include <SCOREP_Memory.h>
#include <SCOREP_Timing.h>

#define SCOREP_DEBUG_MODULE_NAME OPENMP
#include <UTILS_Error.h>
#include <UTILS_Debug.h>

#include "SCOREP_Omp_Target_Events.h"
#include "SCOREP_Omp_Target.h"

#include <opari2/pomp2_lib.h>

void
omp_target_measure_overhead( uint8_t* measured, int deviceId )
{
    if ( ( measured ) && ( *measured == 0 ) )
    {
        UTILS_DEBUG_ENTRY( "device = %d", deviceId );

        int      i, dummy = 0;
        uint64_t version = 0;

        SCOREP_EnterRegion( scorep_omp_target.overheadRegionHandle );

#pragma omp target data map(to:dummy) map(from:version) device(deviceId)
        {
#pragma omp target device(deviceId)
            {
                /* disable MPTI, if OMPT already enabled */
                ompt_control( OMPT_COMMAND_PAUSE, 0 );

#pragma omp parallel for
                for ( i = 0; i < 1; ++i )
                {
                    dummy = i;
                }

                /* enable MPTI */
                ompt_control( OMPT_COMMAND_START, 0 );

                /* check MPTI version */
                uint64_t mpti_version = 0;
                ompt_control( OMPT_COMMAND_VERSION, ( uint64_t )( &mpti_version ) );
                version = mpti_version;
            }
        }

        SCOREP_ExitRegion( scorep_omp_target.overheadRegionHandle );
        *measured = 1;

        if ( version == 0 || version != ( uint64_t )MPTI_VERSION )
        {
            UTILS_WARNING( "MPTI library version %llu found (expected: %u). "
                           "If version is zero, MPTI library might not be "
                           "initialized on target (device %d). "
                           "Make sure it is set in MIC*_LD_PRELOAD!",
                           version, MPTI_VERSION, deviceId );
        }
    }
}

#if ( OMP_MPTI_REFERENCES == 1 )
SCOREP_Omp_Target_Location*
omp_target_get_parent_location( const SCOREP_Omp_Target_Device*   device,
                                const SCOREP_Omp_Target_Location* location,
                                const uint64_t                    parentParallelRegionId )
{
    if ( parentParallelRegionId == INVALID_OMPT_PARALLEL_REGION_ID )
    {
        return NULL;
    }

    SCOREP_Omp_Target_Location* parent_location = device->locations;
    while ( parent_location )
    {
        if ( location != parent_location )
        {
            for ( size_t stackLevel = parent_location->currentStackLevel; stackLevel > 0; --stackLevel )
            {
                if ( parent_location->currentParallelRegionId[ stackLevel ] == parentParallelRegionId )
                {
                    return parent_location;
                }
            }
        }

        parent_location = parent_location->next;
    }

    return NULL;
}
#endif

/*
 * Write record retrieved from MPTI library.
 */
static SCOREP_Omp_Target_Location*
omp_target_write_record( SCOREP_Omp_Target_Device* dev,
                         mpti_record_t*            record )
{
    if ( !scorep_ompcommon_is_finalized )
    {
        SCOREP_Omp_Target_Location* locationIdEntry = dev->locations;
        SCOREP_Omp_Target_Location* lastLocEntry    = dev->locations;
        SCOREP_Location*            location        = SCOREP_INVALID_LOCATION;

        /* find location handle for threadId */
        while ( locationIdEntry )
        {
            if ( locationIdEntry->id == record->thread_id )
            {
                location = locationIdEntry->location;
                break;
            }

            lastLocEntry    = locationIdEntry;
            locationIdEntry = locationIdEntry->next;
        }

        /* find region handle by regionId */
        SCOREP_RegionHandle regionHandle;

        if ( record->pomp_region_id > MPTI_REGION_ID_CUSTOM_END )
        {
            regionHandle = SCOREP_Omp_Common_Target_Region_Get( record->pomp_region_id, record->type );
            UTILS_ASSERT( regionHandle != SCOREP_INVALID_REGION );
        }
        else  /* is barrier or generic id */
        {
            switch ( record->pomp_region_id )
            {
                case MPTI_REGION_ID_BARRIER:
                    regionHandle = scorep_omp_target.barrierRegionHandle;

                    /* do not create a new location for pure barrier threads */
                    if ( !locationIdEntry )
                    {
                        return NULL;
                    }
#if ( OMP_MPTI_REFERENCES == 1 )
                    /*if ( locationIdEntry->currentStackLevel == 0 )
                       {
                        return NULL;
                       }*/
#endif
                    break;

                case MPTI_REGION_ID_IMPLICIT_TASK:
                    regionHandle = scorep_omp_target.implicitTaskRegionHandle;
                    break;

                default:
                    return NULL;
            }
        }

        /* create a new location if necessary */
        if ( !locationIdEntry )
        {
            char locName[ 64 ];
            sprintf( locName, "MIC [%d:%llu]", dev->id, ( long long unsigned )record->thread_id );

            SCOREP_Omp_Target_Location* newEntry =
                ( SCOREP_Omp_Target_Location* )SCOREP_Memory_AllocForMisc(
                    sizeof( SCOREP_Omp_Target_Location ) );

            newEntry->id         = record->thread_id;
            newEntry->internalId = scorep_omp_target.location_counter++;
#if ( OMP_MPTI_REFERENCES == 1 )
            newEntry->currentStackLevel            = 0;
            newEntry->currentParallelRegionId[ 0 ] = INVALID_OMPT_PARALLEL_REGION_ID;
#endif
            newEntry->next     = NULL;
            newEntry->location = SCOREP_Location_CreateNonCPULocation(
                SCOREP_Location_GetCurrentCPULocation(),
                SCOREP_LOCATION_TYPE_GPU,
                locName );

            location        = newEntry->location;
            locationIdEntry = newEntry;

            if ( !lastLocEntry )
            {
                dev->locations = newEntry;
            }
            else
            {
                lastLocEntry->next = newEntry;
            }
        }

        /* write record for region/thread */
        if ( dev->targetHostSyncRatio )
        {
            uint64_t host_pregion_offset = dev->targetHostSyncRatio *
                                           ( double )( record->time - dev->deviceStartTime );

            /* write record */
            switch ( record->type )
            {
                case MPTI_PARALLEL_REGION_ENTER:
                case MPTI_TASK_ENTER:
                case MPTI_TARGET_REGION_ENTER:
                    /* overhead exit record */

#ifdef OPARI
                    /* target region enter on the device */
                    if ( record->type == MPTI_TARGET_REGION_ENTER )
                    {
                        SCOREP_Location_RmaOpCompleteBlocking( SCOREP_Location_GetCurrentCPULocation(),
                                                               dev->hostStartTime + host_pregion_offset,
                                                               scorep_omp_target.interim_window_handle,
                                                               42 + dev->id );
                    }
#endif

#if ( OMP_MPTI_REFERENCES == 1 )
                    if ( record->type == MPTI_PARALLEL_REGION_ENTER )
                    {
                        SCOREP_Omp_Target_Location* parent_location =
                            omp_target_get_parent_location( dev,
                                                            locationIdEntry,
                                                            record->parent_parallel_region_id );

                        if ( parent_location )
                        {
                            SCOREP_LocationHandle location_handle =
                                SCOREP_Location_GetLocationHandle( parent_location->location );

                            SCOREP_Location_AddAttribute( location,
                                                          scorep_omp_target_parent_location_ref_attr,
                                                          &location_handle );
                        }

                        SCOREP_Location_AddAttribute( location,
                                                      scorep_omp_target_region_id_attr,
                                                      &( record->parallel_region_id ) );

                        SCOREP_Location_AddAttribute( location,
                                                      scorep_omp_target_parent_region_id_attr,
                                                      &( record->parent_parallel_region_id ) );

                        locationIdEntry->currentStackLevel++;
                        locationIdEntry->currentParallelRegionId[ locationIdEntry->currentStackLevel ] =
                            record->parallel_region_id;
                    }
#endif

                    SCOREP_Location_EnterRegion(
                        location,
                        dev->hostStartTime + host_pregion_offset,
                        regionHandle );

                    break;

                case MPTI_PARALLEL_REGION_LEAVE:
                case MPTI_TASK_LEAVE:
                case MPTI_TARGET_REGION_LEAVE:
                    SCOREP_Location_ExitRegion(
                        location,
                        dev->hostStartTime + host_pregion_offset,
                        regionHandle );

#if ( OMP_MPTI_REFERENCES == 1 )
                    if ( record->type == MPTI_PARALLEL_REGION_LEAVE )
                    {
                        locationIdEntry->currentParallelRegionId[ locationIdEntry->currentStackLevel ] =
                            INVALID_OMPT_PARALLEL_REGION_ID;
                        locationIdEntry->currentStackLevel--;
                    }
#endif
#ifdef OPARI
                    /* target region leave */
                    if ( record->type == MPTI_TARGET_REGION_LEAVE )
                    {
                        SCOREP_Location_RmaGet( SCOREP_Location_GetCurrentCPULocation(),
                                                dev->hostStartTime + host_pregion_offset,
                                                scorep_omp_target.interim_window_handle,
                                                dev->rmaId,
                                                0, 42 + dev->id );
                        SCOREP_Location_RmaOpCompleteBlocking( SCOREP_Location_GetCurrentCPULocation(),
                                                               dev->hostEndTime,
                                                               scorep_omp_target.interim_window_handle,
                                                               42 + dev->id );
                    }
#endif
                    break;

                default:
                    UTILS_WARNING( "Invalid target region record type." );
            }
        }
        else
        {
            UTILS_WARNING( "Skipping OMP target parallel region (no sync data)" );
        }

        return locationIdEntry;
    }

    return NULL;
}

void
SCOREP_Omp_Target_begin( SCOREP_RegionHandle region, int deviceId )
{
    //TODO: is called before the target region -> map region ID here
#ifdef OPARI
    UTILS_DEBUG_ENTRY( "device = %d", deviceId );
    SCOREP_OMP_ENSURE_INITIALIZED;

    if ( !scorep_ompcommon_is_finalized )
    {
        if ( !scorep_omp_target.transferBuffer )
        {
            scorep_omp_target.transferBuffer = ( mpti_record_t* )SCOREP_Memory_AllocForMisc(
                sizeof( mpti_record_t ) * SCOREP_OMP_TARGET_BUFFER_SIZE );
        }

        omp_target_measure_overhead( &scorep_omp_target.measuredInitialOverhead, deviceId );

        SCOREP_Omp_Target_Device* dev = scorep_omp_target_getcreate_device( deviceId );

        /* create a synchronization point before the target region */
        uint64_t deviceStartTime = 0.0;
 #pragma omp target map(from:deviceStartTime) device(deviceId)
        deviceStartTime = omp_get_wtime() / omp_get_wtick();

        dev->hostStartTime   = SCOREP_GetClockTicks();
        dev->hostEndTime     = 0;
        dev->deviceStartTime = deviceStartTime;

        SCOREP_EnterRegion( region );

        /* create window on every host location, where it is used */
        scorep_omp_target_create_rma_window();

        /* create RDMA location (if necessary) */
        scorep_omp_target_create_rdma_location( dev );

        SCOREP_RmaPut(
            scorep_omp_target.interim_window_handle,
            dev->rmaId,
            0, 42 + dev->id );
    }
#endif
}

void
SCOREP_Omp_Target_end( SCOREP_RegionHandle region, int deviceId )
{
#ifdef OPARI
    UTILS_DEBUG_ENTRY( "device = %d", deviceId );

    if ( !scorep_ompcommon_is_finalized )
    {
        SCOREP_Omp_Target_Device* dev = scorep_omp_target_getcreate_device( deviceId );

        uint64_t deviceEndTime = 0.0;
 #pragma omp target map(from:deviceEndTime) device(deviceId)
        deviceEndTime = omp_get_wtime() / omp_get_wtick();

        dev->hostEndTime = SCOREP_GetClockTicks();
        if ( dev->hostEndTime > dev->hostStartTime )
        {
            if ( deviceEndTime > dev->deviceStartTime )
            {
                dev->targetHostSyncRatio =
                    ( double )( dev->hostEndTime - dev->hostStartTime ) /
                    ( double )( deviceEndTime - dev->deviceStartTime );
            }
            else
            {
                UTILS_WARNING( "OMP target region time (device) <= 0" );
            }
        }
        else
        {
            UTILS_WARNING( "OMP target region time (host) <= 0" );
        }
    }
#endif
}

void
SCOREP_Omp_Target_flush( SCOREP_RegionHandle region, int deviceId )
{
#ifdef OPARI
    SCOREP_OMP_ENSURE_INITIALIZED;
    SCOREP_Omp_Common_offload_flush( region, int deviceId );
#endif
}

void
SCOREP_Omp_Common_offload_flush( SCOREP_RegionHandle region, int deviceId )
{
    UTILS_DEBUG_ENTRY( "device = %d", deviceId );

    if ( !scorep_ompcommon_is_finalized )
    {
        SCOREP_Omp_Target_Device* dev = scorep_omp_target_getcreate_device( deviceId );

        /* insert measurement flush region */
        uint64_t flush_start_time = SCOREP_GetClockTicks();
#if ( OMP_MPTI_REFERENCES == 1 )
        SCOREP_Location* first_record_location = SCOREP_INVALID_LOCATION;
#endif

        /* get number of available records and buffer ptr */
        int num_records = 0;
#pragma omp target map(from:num_records) device(deviceId)
        {
            num_records = 0;
            ompt_control( OMPT_COMMAND_GET_NUM_RECORDS, ( uint64_t )&num_records );
        }

        UTILS_BUG_ON( num_records < 0,
                      "MPTI measurement buffer overflow on target device (error = %d)!\n", num_records );

        int offset = 0;
        while ( num_records > 0 )
        {
            /* read records from device */
            mpti_record_t* records     = scorep_omp_target.transferBuffer;
            int            transfer_ct = ( num_records > SCOREP_OMP_TARGET_BUFFER_SIZE ) ?
                                         SCOREP_OMP_TARGET_BUFFER_SIZE : num_records;

#pragma omp target map(to:offset,transfer_ct) map(from:records[0:transfer_ct]) device(deviceId)
            {
                int            i;
                mpti_record_t* buffer_ptr;

                /* get ptr to record buffer */
                ompt_control( OMPT_COMMAND_FLUSH_RECORDS, ( uint64_t )&buffer_ptr );
                for ( i = 0; i < transfer_ct; ++i )
                {
                    records[ i ] = buffer_ptr[ offset + i ];
                }
            }

            /* write records */
            int r;
            for ( r = 0; r < transfer_ct; ++r )
            {
                mpti_record_t* record = &( records[ r ] );
#if ( OMP_MPTI_REFERENCES == 1 )
                SCOREP_Omp_Target_Location* record_location_entry =
#endif
                omp_target_write_record( dev, record );

#if ( OMP_MPTI_REFERENCES == 1 )
                if ( record_location_entry )
                {
                    if ( first_record_location == SCOREP_INVALID_LOCATION )
                    {
                        first_record_location = record_location_entry->location;
                    }
                }
#endif
            }

            offset      += transfer_ct;
            num_records -= transfer_ct;
        }

        // write flush enter on the host
        SCOREP_Location_EnterRegion( SCOREP_Location_GetCurrentCPULocation(),
                                     flush_start_time,
                                     scorep_omp_target.flushRegionHandle );

#if ( OMP_MPTI_REFERENCES == 1 )
        /* add reference to first device location */
        if ( first_record_location != SCOREP_INVALID_LOCATION )
        {
            SCOREP_LocationHandle location_handle =
                SCOREP_Location_GetLocationHandle( first_record_location );

            SCOREP_AddAttribute( scorep_omp_target_location_ref_attr, &location_handle );
        }
#endif

        SCOREP_ExitRegion( scorep_omp_target.flushRegionHandle );

#ifdef OPARI
        SCOREP_ExitRegion( region );
#endif
    }
}

void
SCOREP_Omp_Target_copy_begin( SCOREP_RegionHandle region, uint8_t direction, int deviceId )
{
#ifdef OPARI
    UTILS_DEBUG_ENTRY( "device = %d", deviceId );
    SCOREP_OMP_ENSURE_INITIALIZED;

    if ( !scorep_ompcommon_is_finalized )
    {
        SCOREP_Omp_Target_Device* dev = scorep_omp_target_getcreate_device( deviceId );

        // create window on every host location, where it is used
        scorep_omp_target_create_rma_window();

        // create RDMA location (if necessary)
        scorep_omp_target_create_rdma_location( dev );

        if ( direction == 0 ) // h2d
        {
            omp_target_measure_overhead( &scorep_omp_target.measuredInitialOverhead,
                                         deviceId );

            // target data region
            SCOREP_EnterRegion( region );
        }

        //TODO: no enter region for d2h / RMA get? Why

        // add rdma copy
        if ( direction == 0 )     // h2d
        {
            SCOREP_RmaPut(
                scorep_omp_target.interim_window_handle,
                dev->rmaId,
                0, 42 + deviceId );
        }
        else     // d2h
        {
            SCOREP_RmaGet(
                scorep_omp_target.interim_window_handle,
                dev->rmaId,
                0, 42 + deviceId );
        }
    }
#endif
}

void
SCOREP_Omp_Target_copy_end( SCOREP_RegionHandle region, uint8_t direction, int deviceId )
{
#ifdef OPARI
    UTILS_DEBUG_ENTRY( "device = %d", deviceId );
    SCOREP_OMP_ENSURE_INITIALIZED;

    if ( !scorep_ompcommon_is_finalized )
    {
        SCOREP_Omp_Target_Device* dev = scorep_omp_target_getcreate_device( deviceId );

        // add rdma copy
        if ( SCOREP_INVALID_OMP_TARGET_ID != dev->rmaId )
        {
            SCOREP_Location_RmaOpCompleteBlocking( SCOREP_Location_GetCurrentCPULocation(),
                                                   SCOREP_GetClockTicks(),
                                                   scorep_omp_target.interim_window_handle,
                                                   42 + deviceId );
        }

        if ( direction == 1 )
        {
            // target data region
            SCOREP_ExitRegion( region );
        }
    }
#endif
}


void
SCOREP_Omp_Target_update_begin( SCOREP_RegionHandle region, uint8_t direction, int deviceId )
{
#ifdef OPARI
    UTILS_DEBUG_ENTRY( "device = %d", deviceId );
    SCOREP_OMP_ENSURE_INITIALIZED;

    if ( !scorep_ompcommon_is_finalized )
    {
        SCOREP_Omp_Target_Device* dev = scorep_omp_target_getcreate_device( deviceId );

        /* create window on every host location, where it is used */
        scorep_omp_target_create_rma_window();

        /* create RDMA location (if necessary) */
        scorep_omp_target_create_rdma_location( dev );

        // record measurement overhead, if it is not yet recorded
        omp_target_measure_overhead( &scorep_omp_target.measuredInitialOverhead,
                                     deviceId );

        SCOREP_Location* location = SCOREP_Location_GetCurrentCPULocation();
        uint64_t         time     = SCOREP_GetClockTicks();

        {
            /* target data region on host device */
            SCOREP_Location_EnterRegion( location,
                                         time,
                                         region );

            /* target data region on RDMA target device */
            SCOREP_Location_EnterRegion( dev->rmaLocation,
                                         time,
                                         region );
        }

        /* add rdma copy */
        if ( direction == 1 )     /* h2d */
        {
            SCOREP_Location_RmaPut(
                location,
                time,
                scorep_omp_target.interim_window_handle,
                dev->rmaId,
                0, 42 + deviceId );
        }
        else if ( direction == 2 )    /* d2h */
        {
            SCOREP_Location_RmaGet(
                location,
                time,
                scorep_omp_target.interim_window_handle,
                dev->rmaId,
                0, 42 + deviceId );
        }
        else /* h2d & d2h */
        {
            SCOREP_Location_RmaPut(
                location,
                time,
                scorep_omp_target.interim_window_handle,
                dev->rmaId,
                0, 42 + deviceId );

            SCOREP_Location_RmaGet(
                location,
                time,
                scorep_omp_target.interim_window_handle,
                dev->rmaId,
                0, 42 + deviceId + 1 );
        }
    }
#endif
}

void
SCOREP_Omp_Target_update_end( SCOREP_RegionHandle region, uint8_t direction, int deviceId )
{
#ifdef OPARI
    UTILS_DEBUG_ENTRY( "device = %d", deviceId );
    SCOREP_OMP_ENSURE_INITIALIZED;

    if ( !scorep_ompcommon_is_finalized )
    {
        SCOREP_Omp_Target_Device* dev = scorep_omp_target_getcreate_device( deviceId );

        SCOREP_Location* location = SCOREP_Location_GetCurrentCPULocation();
        uint64_t         time     = SCOREP_GetClockTicks();

        /* add rdma copy */
        if ( SCOREP_INVALID_OMP_TARGET_ID != dev->rmaId )
        {
            SCOREP_Location_RmaOpCompleteBlocking(
                location,
                time,
                scorep_omp_target.interim_window_handle,
                42 + deviceId );


            if ( direction == 0 )
            {
                SCOREP_Location_RmaOpCompleteBlocking(
                    location,
                    time,
                    scorep_omp_target.interim_window_handle,
                    42 + deviceId + 1 );
            }
        }

        /* target data region */
        SCOREP_Location_ExitRegion( location,
                                    time,
                                    region );


        /* target data region on RDMA target device */
        SCOREP_Location_ExitRegion( dev->rmaLocation,
                                    time,
                                    region );
    }
#endif
}

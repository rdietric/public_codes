/*
 * This file is part of the Score-P software (http://www.score-p.org)
 *
 * Copyright (c) 2014,
 * Technische Universitaet Dresden, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license. See the COPYING file in the package base
 * directory for details.
 *
 */

#include <config.h>
#include <stddef.h>

#include <SCOREP_Events.h>
#include <SCOREP_Memory.h>
#include <SCOREP_Timing.h>


#define SCOREP_DEBUG_MODULE_NAME OPENMP
#include <UTILS_Error.h>
#include <UTILS_Debug.h>

#include "SCOREP_Omp_Target.h"

#if ( OMP_MPTI_REFERENCES == 1 )
/* String constants for OMP Target attribute references */
#define SCOREP_OMP_TARGET_LOCATIONREF_KEY         "OMP_TARGET_LOCATION_REF"
#define SCOREP_OMP_TARGET_PARENT_LOCATIONREF_KEY  "OMP_TARGET_PARENT_LOCATION_REF"
#define SCOREP_OMP_TARGET_REGION_ID_KEY           "OMP_TARGET_REGION_ID"
#define SCOREP_OMP_TARGET_PARENT_REGION_ID_KEY    "OMP_TARGET_PARENT_REGION_ID"
#endif

/**************************************************************************
                             Declarations
**************************************************************************/

/** Flag to indicate whether the adapter is initialized */
bool scorep_ompcommon_is_initialized = false;

/** Flag to indicate whether the adapter is finalized */
bool scorep_ompcommon_is_finalized = false;

SCOREP_Omp_Target_Info scorep_omp_target;

#if ( OMP_MPTI_REFERENCES == 1 )
SCOREP_AttributeHandle scorep_omp_target_location_ref_attr;
SCOREP_AttributeHandle scorep_omp_target_parent_location_ref_attr;
SCOREP_AttributeHandle scorep_omp_target_region_id_attr;
SCOREP_AttributeHandle scorep_omp_target_parent_region_id_attr;
#endif

/**************************************************************************
                             Implementation
**************************************************************************/

size_t
scorep_omp_target_create_comm_group( uint64_t** globalLocationIds )
{
    size_t                       count  = 0;
    SCOREP_Omp_Target_Device*    device = NULL;
    SCOREP_Omp_Target_RmaWindow* window = NULL;

    /* get the number of OMP target communication partners */
    /* add target threads */
    device = scorep_omp_target.devices;
    while ( device != NULL )
    {
        SCOREP_Omp_Target_Location* entry_loc = device->locations;
        while ( entry_loc != NULL )
        {
            count++;
            entry_loc = entry_loc->next;
        }

        /* add RDMA location */
        if ( SCOREP_INVALID_OMP_TARGET_ID != device->rmaId )
        {
            count++;
        }

        device = device->next;
    }

    window = scorep_omp_target.rmaWindows;
    while ( window != NULL )
    {
        count++;
        window = window->next;
    }

    if ( count == 0 )
    {
        return count;
    }

    /* allocate the OMP target communication group array */
    *globalLocationIds = ( uint64_t* )SCOREP_Memory_AllocForMisc( count * sizeof( uint64_t ) );

    /* add the communication partners allocated array */
    device = scorep_omp_target.devices;
    while ( device != NULL )
    {
        SCOREP_Omp_Target_Location* entry_loc = device->locations;
        while ( entry_loc != NULL )
        {
            ( *globalLocationIds )[ entry_loc->internalId ] =
                SCOREP_Location_GetGlobalId( entry_loc->location );

            entry_loc = entry_loc->next;
        }

        if ( SCOREP_INVALID_OMP_TARGET_ID != device->rmaId )
        {
            ( *globalLocationIds )[ device->rmaId ] =
                SCOREP_Location_GetGlobalId( device->rmaLocation );
        }

        device = device->next;
    }

    window = scorep_omp_target.rmaWindows;
    while ( window != NULL )
    {
        ( *globalLocationIds )[ window->internalId ] =
            SCOREP_Location_GetGlobalId( window->location );
        window = window->next;
    }

    return count;
}

void
scorep_omp_target_create_rma_window( void )
{
    SCOREP_Omp_Target_RmaWindow* window = scorep_omp_target.rmaWindows;

    SCOREP_Location* currentLocation = SCOREP_Location_GetCurrentCPULocation();

    while ( window )
    {
        if ( window->location == currentLocation )
        {
            /* return if RMA window already created for this location */
            return;
        }

        window = window->next;
    }

    window = ( SCOREP_Omp_Target_RmaWindow* )SCOREP_Memory_AllocForMisc(
        sizeof( SCOREP_Omp_Target_RmaWindow ) );

    window->location   = currentLocation;
    window->internalId = scorep_omp_target.location_counter++;
    window->next       = scorep_omp_target.rmaWindows;

    scorep_omp_target.rmaWindows = window;

    SCOREP_RmaWinCreate( scorep_omp_target.interim_window_handle );
}

void
scorep_omp_target_destroy_rma_windows( void )
{
    SCOREP_Omp_Target_RmaWindow* window = scorep_omp_target.rmaWindows;

    while ( window )
    {
        SCOREP_Location_RmaWinDestroy( window->location,
                                       SCOREP_GetClockTicks(),
                                       scorep_omp_target.interim_window_handle );

        window = window->next;
    }
}

void
scorep_omp_target_create_rdma_location( SCOREP_Omp_Target_Device* dev )
{
    /* create a RDMA location for each target device */
    if ( dev && SCOREP_INVALID_OMP_TARGET_ID == dev->rmaId )
    {
        char locName[ 256 ];
        sprintf( locName, "MIC [%d:RDMA]", dev->id );

        dev->rmaId       = scorep_omp_target.location_counter++;
        dev->rmaLocation = SCOREP_Location_CreateNonCPULocation(
            SCOREP_Location_GetCurrentCPULocation(),
            SCOREP_LOCATION_TYPE_GPU,
            locName );
    }
}

SCOREP_Omp_Target_Device*
scorep_omp_target_getcreate_device( int id )
{
    UTILS_ASSERT( id >= 0 );
    SCOREP_Omp_Target_Device* entry = scorep_omp_target.devices;

    /* lookup device by id */
    while ( entry )
    {
        if ( entry->id == id )
        {
            return entry;
        }

        entry = entry->next;
    }

    /* not found, create new entry and append to list */
    entry = ( SCOREP_Omp_Target_Device* )SCOREP_Memory_AllocForMisc(
        sizeof( SCOREP_Omp_Target_Device ) );

    entry->deviceStartTime     = 0;
    entry->hostStartTime       = 0;
    entry->id                  = id;
    entry->rmaId               = SCOREP_INVALID_OMP_TARGET_ID;
    entry->locations           = NULL;
    entry->rmaLocation         = SCOREP_INVALID_LOCATION;
    entry->targetHostSyncRatio = 0.0;
    entry->next                = scorep_omp_target.devices;
    scorep_omp_target.devices  = entry;

    return entry;
}

uint8_t
scorep_omp_target_is_target_location( SCOREP_Location* location )
{
    SCOREP_Omp_Target_Device*    entry_device = NULL;
    SCOREP_Omp_Target_RmaWindow* entry_window = NULL;

    entry_device = scorep_omp_target.devices;
    while ( entry_device != NULL )
    {
        SCOREP_Omp_Target_Location* entry_loc = entry_device->locations;
        while ( entry_loc != NULL )
        {
            if ( entry_loc->location == location )
            {
                return 1;
            }
            entry_loc = entry_loc->next;
        }

        /* check for RDMA location */
        if ( SCOREP_INVALID_OMP_TARGET_ID != entry_device->rmaId )
        {
            if ( entry_device->rmaLocation == location )
            {
                return 1;
            }
        }

        entry_device = entry_device->next;
    }

    entry_window = scorep_omp_target.rmaWindows;
    while ( entry_window != NULL )
    {
        if ( entry_window->location == location )
        {
            return 1;
        }
        entry_window = entry_window->next;
    }

    return 0;
}

static int
scorep_omp_target_finalize_callback( void )
{
    if ( scorep_ompcommon_is_finalized )
    {
        return 0;
    }
    scorep_ompcommon_is_finalized = true;

    scorep_omp_target.global_location_count =
        scorep_omp_target_create_comm_group( &scorep_omp_target.global_location_ids );

    /* destroy window on every location, where it is used */
    scorep_omp_target_destroy_rma_windows();
}

void
SCOREP_Omp_Target_Init()
{
    if ( scorep_ompcommon_is_initialized )
    {
        return;
    }
    scorep_ompcommon_is_initialized = true;

    scorep_omp_target.devices                 = NULL;
    scorep_omp_target.rmaWindows              = NULL;
    scorep_omp_target.transferBuffer          = NULL;
    scorep_omp_target.measuredInitialOverhead = 0;
    scorep_omp_target.location_counter        = 0;
    scorep_omp_target.global_location_count   = 0;
    scorep_omp_target.global_location_ids     = NULL;

    /* create interim communicator once for a process */
    scorep_omp_target.interim_communicator_handle =
        SCOREP_Definitions_NewInterimCommunicator(
            SCOREP_INVALID_INTERIM_COMMUNICATOR,
            SCOREP_PARADIGM_MIC,
            0,
            NULL );

    scorep_omp_target.interim_window_handle =
        SCOREP_Definitions_NewInterimRmaWindow(
            "MIC_WINDOW",
            scorep_omp_target.interim_communicator_handle );

    scorep_omp_target.fileHandle = SCOREP_Definitions_NewSourceFile( "MIC" );

    scorep_omp_target.barrierRegionHandle = SCOREP_Definitions_NewRegion(
        "!$omp barrier", NULL, scorep_omp_target.fileHandle,
        SCOREP_INVALID_LINE_NO, SCOREP_INVALID_LINE_NO,
        SCOREP_PARADIGM_MIC, SCOREP_REGION_BARRIER );

    scorep_omp_target.implicitTaskRegionHandle = SCOREP_Definitions_NewRegion(
        "!$omp implicit task", NULL, scorep_omp_target.fileHandle,
        SCOREP_INVALID_LINE_NO, SCOREP_INVALID_LINE_NO,
        SCOREP_PARADIGM_MIC, SCOREP_REGION_TASK );

    scorep_omp_target.flushRegionHandle = SCOREP_Definitions_NewRegion(
        "!$omp offloading flush", NULL, SCOREP_INVALID_SOURCE_FILE,
        SCOREP_INVALID_LINE_NO, SCOREP_INVALID_LINE_NO,
        SCOREP_PARADIGM_MEASUREMENT, SCOREP_REGION_FLUSH );

    scorep_omp_target.overheadRegionHandle = SCOREP_Definitions_NewRegion(
        "!$omp offloading overhead", NULL, SCOREP_INVALID_SOURCE_FILE,
        SCOREP_INVALID_LINE_NO, SCOREP_INVALID_LINE_NO,
        SCOREP_PARADIGM_MIC, SCOREP_REGION_IMPLICIT_BARRIER );

#if ( OMP_MPTI_REFERENCES == 1 )
    scorep_omp_target_location_ref_attr = SCOREP_Definitions_NewAttribute(
        SCOREP_OMP_TARGET_LOCATIONREF_KEY, NULL, SCOREP_ATTRIBUTE_TYPE_LOCATION );

    scorep_omp_target_parent_location_ref_attr = SCOREP_Definitions_NewAttribute(
        SCOREP_OMP_TARGET_PARENT_LOCATIONREF_KEY, NULL, SCOREP_ATTRIBUTE_TYPE_LOCATION );

    scorep_omp_target_region_id_attr = SCOREP_Definitions_NewAttribute(
        SCOREP_OMP_TARGET_REGION_ID_KEY, NULL, SCOREP_ATTRIBUTE_TYPE_UINT64 );

    scorep_omp_target_parent_region_id_attr = SCOREP_Definitions_NewAttribute(
        SCOREP_OMP_TARGET_PARENT_REGION_ID_KEY, NULL, SCOREP_ATTRIBUTE_TYPE_UINT64 );
#endif

    SCOREP_RegisterExitCallback( scorep_omp_target_finalize_callback );
}

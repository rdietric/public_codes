/*
 * This file is part of the Score-P software (http://www.score-p.org)
 *
 * Copyright (c) 2009-2011,
 * RWTH Aachen University, Germany
 *
 * Copyright (c) 2009-2011,
 * Gesellschaft fuer numerische Simulation mbH Braunschweig, Germany
 *
 * Copyright (c) 2009-2011,
 * Technische Universitaet Dresden, Germany
 *
 * Copyright (c) 2009-2011,
 * University of Oregon, Eugene, USA
 *
 * Copyright (c) 2009-2013,
 * Forschungszentrum Juelich GmbH, Germany
 *
 * Copyright (c) 2009-2011,
 * German Research School for Simulation Sciences GmbH, Juelich/Aachen, Germany
 *
 * Copyright (c) 2009-2011,
 * Technische Universitaet Muenchen, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license.  See the COPYING file in the package base
 * directory for details.
 */

#ifndef SCOREP_POMP_TARGET_H
#define SCOREP_POMP_TARGET_H

#include "SCOREP_Pomp_RegionInfo.h"


typedef struct SCOREP_Pomp_Target_Region_Map_Entry
{
    uint64_t            id;                      /* POMP region id */
    SCOREP_Pomp_Region* handle;                  /* POMP region handle */
}SCOREP_Pomp_Target_Region_Map_Entry;

typedef struct SCOREP_Pomp_Target_Region_Map
{
    uint64_t                             size;    /* Size of memory array aka maximum number of entries storable before realloc */
    uint64_t                             count;   /* Number of entries in the map */
    SCOREP_Pomp_Target_Region_Map_Entry* entries; /* Array of entries */
}SCOREP_Pomp_Target_Region_Map;

#endif  /* SCOREP_POMP_TARGET_H */

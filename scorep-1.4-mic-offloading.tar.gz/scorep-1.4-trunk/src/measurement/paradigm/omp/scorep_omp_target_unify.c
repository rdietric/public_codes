/*
 * This file is part of the Score-P software (http://www.score-p.org)
 *
 * Copyright (c) 2009-2014,
 * Technische Universitaet Dresden, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license. See the COPYING file in the package base
 * directory for details.
 *
 */

#include <config.h>

#include <UTILS_Error.h>
#define SCOREP_DEBUG_MODULE_NAME OMP
#include <UTILS_Debug.h>

#include <SCOREP_Types.h>
#include <SCOREP_Definitions.h>
#include <SCOREP_Memory.h>

#include <scorep_unify_helpers.h>

#include <SCOREP_Omp_Target.h>

void
scorep_omp_define_target_locations( void )
{
    size_t   i      = 0;
    uint32_t offset = scorep_unify_helper_define_comm_locations(
        SCOREP_GROUP_TARGET_LOCATIONS,
        "MIC_LOCATIONS", scorep_omp_target.global_location_count,
        scorep_omp_target.global_location_ids );

    /* add the offset */
    for ( i = 0; i < scorep_omp_target.global_location_count; i++ )
    {
        scorep_omp_target.global_location_ids[ i ] = i + offset;
    }

    SCOREP_GroupHandle group_handle = SCOREP_Definitions_NewGroup(
        SCOREP_GROUP_TARGET_GROUP,
        "MIC_GROUP",
        scorep_omp_target.global_location_count,
        scorep_omp_target.global_location_ids );

    SCOREP_CommunicatorHandle communicator_handle =
        SCOREP_Definitions_NewCommunicator(
            group_handle,
            "",
            SCOREP_INVALID_COMMUNICATOR );

    SCOREP_RmaWindowHandle window_handle = SCOREP_Definitions_NewRmaWindow(
        "",
        communicator_handle );

    SCOREP_LOCAL_HANDLE_DEREF( scorep_omp_target.interim_communicator_handle,
                               InterimCommunicator )->unified =
        communicator_handle;

    SCOREP_LOCAL_HANDLE_DEREF( scorep_omp_target.interim_window_handle, InterimRmaWindow )->unified =
        window_handle;
}

void
scorep_omp_define_target_group( void )
{
    scorep_local_definition_manager.interim_communicator.mapping[
        SCOREP_LOCAL_HANDLE_DEREF( scorep_omp_target.interim_communicator_handle,
                                   InterimCommunicator )->sequence_number ] =
        scorep_local_definition_manager.communicator.mapping[
            SCOREP_LOCAL_HANDLE_DEREF( SCOREP_LOCAL_HANDLE_DEREF(
                                           scorep_omp_target.interim_communicator_handle,
                                           InterimCommunicator )->unified,
                                       Communicator )->sequence_number ];

    scorep_local_definition_manager.interim_rma_window.mapping[
        SCOREP_LOCAL_HANDLE_DEREF( scorep_omp_target.interim_window_handle,
                                   InterimRmaWindow )->sequence_number ] =
        scorep_local_definition_manager.rma_window.mapping[
            SCOREP_LOCAL_HANDLE_DEREF( SCOREP_LOCAL_HANDLE_DEREF(
                                           scorep_omp_target.interim_window_handle,
                                           InterimRmaWindow )->unified, RmaWindow )->sequence_number ];
}

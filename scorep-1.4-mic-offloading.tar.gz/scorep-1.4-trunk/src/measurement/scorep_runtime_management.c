/*
 * This file is part of the Score-P software (http://www.score-p.org)
 *
 * Copyright (c) 2009-2013,
 * RWTH Aachen University, Germany
 *
 * Copyright (c) 2009-2013,
 * Gesellschaft fuer numerische Simulation mbH Braunschweig, Germany
 *
 * Copyright (c) 2009-2014,
 * Technische Universitaet Dresden, Germany
 *
 * Copyright (c) 2009-2013,
 * University of Oregon, Eugene, USA
 *
 * Copyright (c) 2009-2014,
 * Forschungszentrum Juelich GmbH, Germany
 *
 * Copyright (c) 2009-2013,
 * German Research School for Simulation Sciences GmbH, Juelich/Aachen, Germany
 *
 * Copyright (c) 2009-2013,
 * Technische Universitaet Muenchen, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license. See the COPYING file in the package base
 * directory for details.
 *
 */


/**
 * @file
 *
 *
 */

#include <config.h>
#include "scorep_runtime_management.h"

#include <SCOREP_Timing.h>
#include <UTILS_Error.h>
#include <UTILS_IO.h>
#include <SCOREP_Thread_Mgmt.h>
#include <SCOREP_Memory.h>
#include <SCOREP_Config.h>
#include "scorep_status.h"
#include "scorep_ipc.h"
#include <SCOREP_Definitions.h>
#include <SCOREP_Location.h>
#include "scorep_environment.h"

#include <stdio.h>
#include <time.h>
#include <string.h>
#include <assert.h>
#include <stdlib.h>
#include <stdbool.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <inttypes.h>


/** @def WORK_DIR_SIZE length for buffer storing the current working directory */
#define WORK_DIR_SIZE 1024

/** @def FORMAT_TIME_SIZE length for generated experiment directory names based on timestamp */
#define FORMAT_TIME_SIZE  128

/** @def SCOREP_FAILED_DIR_NAME_PREFIX directory name prefix of failed Score-P measurement runs */
#define SCOREP_FAILED_DIR_NAME_PREFIX "scorep-failed-"

/** @def SCOREP_DIR_NAME_PREFIX directory name prefix of Score-P measurement runs */
#define SCOREP_DIR_NAME_PREFIX "scorep-"

/** @def SCOREP_TMP_DIR_NAME name of temporary Score-P directory */
#define SCOREP_TMP_DIR_NAME "scorep-measurement-tmp"


/* *INDENT-OFF* */
extern bool scorep_create_experiment_dir(void (*createDir) (void) );
static void scorep_create_directory( void );
static void scorep_create_experiment_dir_name( void );
static bool scorep_dir_name_is_created( void );
static void scorep_dump_config( void );
/* *INDENT-ON* */


static char scorep_working_directory[ WORK_DIR_SIZE ];
static char* scorep_experiment_dir_name;
static bool  scorep_experiment_dir_needs_rename;


const char*
SCOREP_GetExperimentDirName( void )
{
    scorep_create_experiment_dir_name();
    return scorep_experiment_dir_name;
}


void
SCOREP_CreateExperimentDir( void )
{
    if ( SCOREP_Status_IsExperimentDirCreated() )
    {
        return;
    }
    scorep_create_experiment_dir_name();

    if ( scorep_create_experiment_dir( scorep_create_directory ) )
    {
        SCOREP_OnExperimentDirCreation();

        /* dump the measurement configuration early, so that it is also
           available in case of failure */
        scorep_dump_config();
    }
}


void
scorep_create_experiment_dir_name( void )
{
    if ( scorep_dir_name_is_created() )
    {
        return;
    }

    const char* env_get_experiment_dir_name;
    env_get_experiment_dir_name = SCOREP_Env_GetExperimentDirectory();

    scorep_working_directory[ 0 ] = '\0';

    if ( UTILS_IO_GetCwd( scorep_working_directory, sizeof( scorep_working_directory ) - 1 ) == NULL )
    {
        UTILS_ERROR_POSIX( "Error while getting absolute path name of the current working directory." );
        _Exit( EXIT_FAILURE );
    }

    if ( strlen( env_get_experiment_dir_name ) == 0 )
    {
        /*
         * if the user does not specified an experiment name,
         * use default temporary directory name and rename it to a timestamp based
         * at the end.
         */

        scorep_experiment_dir_name = UTILS_IO_JoinPath( 2, scorep_working_directory,
                                                        SCOREP_TMP_DIR_NAME );
        scorep_experiment_dir_needs_rename = true;
    }
    else
    {
        /*
         * if the user specified an experiment name, use this one,
         * no need to rename it at the end
         */

        /*
         * If env_get_experiment_dir_name contains an absolute path,
         * scorep_working_directory will be skipped by UTILS_IO_JoinPath,
         * otherwise scorep_experiment_dir_name is set to scorep_working_directory +
         * path separator + env_get_experiment_dir_name
         */
        scorep_experiment_dir_name = UTILS_IO_JoinPath( 2, scorep_working_directory,
                                                        env_get_experiment_dir_name );
        scorep_experiment_dir_needs_rename = false;
    }
}


bool
scorep_dir_name_is_created( void )
{
    return scorep_experiment_dir_name && 0 < strlen( scorep_experiment_dir_name );
}


static const char*
scorep_format_time( time_t* timestamp )
{
    static char local_time_buf[ FORMAT_TIME_SIZE ];
    time_t      now;
    struct tm*  local_time;

    if ( timestamp == NULL )
    {
        time( &now );
        timestamp = &now;
    }

    local_time = localtime( timestamp );
    if ( local_time == NULL )
    {
        perror( "localtime should not fail." );
        _Exit( EXIT_FAILURE );
    }

    strftime( local_time_buf, FORMAT_TIME_SIZE - 1, "%Y%m%d_%H%M_", local_time );
    snprintf( &( local_time_buf[ strlen( local_time_buf ) ] ),
              FORMAT_TIME_SIZE - strlen( local_time_buf ) - 1,
              "%" PRIu64, SCOREP_GetClockTicks() );
    local_time_buf[ FORMAT_TIME_SIZE - 1 ] = '\0';

    return local_time_buf;
}


void
scorep_create_directory( void )
{
    //first check to see if directory already exists.
    struct stat buf;
    mode_t      mode = S_IRUSR | S_IWUSR | S_IXUSR | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH;

    /* rename an existing experiment directory */
    if ( stat( scorep_experiment_dir_name, &buf ) != -1 )
    {
        /*
         * fail if the previous entry exists and is not an directory at all
         */
        if ( !S_ISDIR( buf.st_mode ) )
        {
            UTILS_ERROR( SCOREP_ERROR_ENOTDIR,
                         "Experiment directory \"%s\" exists but is not an directory.",
                         scorep_experiment_dir_name );
            _Exit( EXIT_FAILURE );
        }


        if ( scorep_experiment_dir_needs_rename )
        {
            /*
             * we use the default temporary directory,
             * rename previous failed runs away
             */
            char* tmp = calloc( strlen( SCOREP_FAILED_DIR_NAME_PREFIX ) + FORMAT_TIME_SIZE + 1,
                                sizeof( char ) );
            UTILS_ASSERT( tmp );
            strncat( tmp, SCOREP_FAILED_DIR_NAME_PREFIX, strlen( SCOREP_FAILED_DIR_NAME_PREFIX ) );
            strncat( tmp, scorep_format_time( NULL ), FORMAT_TIME_SIZE );
            char* failed_experiment_dir_name = UTILS_IO_JoinPath( 2, scorep_working_directory, tmp );

            if ( rename( scorep_experiment_dir_name, failed_experiment_dir_name ) != 0 )
            {
                UTILS_ERROR_POSIX( "Can't rename experiment directory \"%s\" to \"%s\".",
                                   scorep_experiment_dir_name, failed_experiment_dir_name );
                _Exit( EXIT_FAILURE );
            }
            free( failed_experiment_dir_name );
            free( tmp );
        }
        else
        {
            /*
             * fail if this experiment directory exists and the user
             * commands us to do so
             */
            if ( !SCOREP_Env_DoOverwriteExperimentDirectory() )
            {
                UTILS_ERROR( SCOREP_ERROR_EEXIST,
                             "Experiment directory \"%s\" exists and overwriting is disabled.",
                             scorep_experiment_dir_name );
                _Exit( EXIT_FAILURE );
            }

            /* rename a previous run away by appending a timestamp */
            const char* local_time_buf              = scorep_format_time( &buf.st_mtime );
            char*       old_experiment_dir_name_buf = calloc( strlen( scorep_experiment_dir_name )
                                                              + 1 + strlen( local_time_buf )
                                                              + 1,
                                                              sizeof( char ) );
            assert( old_experiment_dir_name_buf );
            strcpy( old_experiment_dir_name_buf, scorep_experiment_dir_name );
            strcat( old_experiment_dir_name_buf, "-" );
            strcat( old_experiment_dir_name_buf, local_time_buf );
            if ( rename( scorep_experiment_dir_name, old_experiment_dir_name_buf ) != 0 )
            {
                UTILS_ERROR_POSIX( "Can't rename old experiment directory \"%s\" to \"%s\".",
                                   scorep_experiment_dir_name, old_experiment_dir_name_buf );
                _Exit( EXIT_FAILURE );
            }
            if ( SCOREP_Env_RunVerbose() )
            {
                printf( "[Score-P] previous experiment directory: %s\n", old_experiment_dir_name_buf );
            }
            free( old_experiment_dir_name_buf );
        }
    }

    if ( mkdir( scorep_experiment_dir_name, mode ) == -1 )
    {
        UTILS_ERROR_POSIX( "Can't create experiment directory \"%s\".",
                           scorep_experiment_dir_name );
        _Exit( EXIT_FAILURE );
    }

    if ( SCOREP_Env_RunVerbose() )
    {
        printf( "[Score-P] experiment directory: %s\n", scorep_experiment_dir_name );
    }
}


void
SCOREP_RenameExperimentDir( void )
{
    SCOREP_Ipc_Barrier();
    if ( SCOREP_Status_GetRank() > 0 )
    {
        return;
    }

    if ( !SCOREP_Status_IsExperimentDirCreated() )
    {
        return;
    }

    if ( !scorep_experiment_dir_needs_rename )
    {
        return;
    }

    /*
     * we use the default temporary directory,
     * thus rename it to a timestamped based directory name
     */
    char* tmp = calloc( strlen( SCOREP_DIR_NAME_PREFIX ) + FORMAT_TIME_SIZE + 1,
                        sizeof( char ) );
    UTILS_ASSERT( tmp );
    strncat( tmp, SCOREP_DIR_NAME_PREFIX, strlen( SCOREP_DIR_NAME_PREFIX ) );
    strncat( tmp, scorep_format_time( NULL ), FORMAT_TIME_SIZE );
    char* new_experiment_dir_name = UTILS_IO_JoinPath( 2, scorep_working_directory, tmp );

    if ( rename( scorep_experiment_dir_name, new_experiment_dir_name ) != 0 )
    {
        UTILS_ERROR_POSIX( "Can't rename experiment directory from \"%s\" to \"%s\".",
                           scorep_experiment_dir_name, new_experiment_dir_name );
        _Exit( EXIT_FAILURE );
    }

    if ( SCOREP_Env_RunVerbose() )
    {
        printf( "[Score-P] final experiment directory: %s\n", new_experiment_dir_name );
    }
    free( new_experiment_dir_name );
    free( tmp );
}

static void
scorep_dump_config( void )
{
    if ( SCOREP_Status_IsMpp() && SCOREP_Status_GetRank() != 0 )
    {
        return;
    }

    char* dump_file_name = UTILS_IO_JoinPath(
        2, SCOREP_GetExperimentDirName(), "scorep.cfg" );
    if ( !dump_file_name )
    {
        UTILS_ERROR( SCOREP_ERROR_MEM_ALLOC_FAILED,
                     "Can't write measurement configuration" );

        return;
    }

    FILE* dump_file = fopen( dump_file_name, "w" );
    if ( !dump_file )
    {
        UTILS_ERROR( SCOREP_ERROR_FILE_CAN_NOT_OPEN,
                     "Can't write measurement configuration into `%s'",
                     dump_file_name );

        free( dump_file_name );
        return;
    }
    free( dump_file_name );

    SCOREP_ConfigDump( dump_file );
    fclose( dump_file );
}

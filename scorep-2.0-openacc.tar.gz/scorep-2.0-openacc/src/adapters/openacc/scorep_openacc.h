/*
 * This file is part of the Score-P software (http://www.score-p.org)
 *
 * Copyright (c) 2014,
 * Technische Universitaet Dresden, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license. See the COPYING file in the package base
 * directory for details.
 *
 */

/**
 *  @file
 *
 *  This file provides commonly used definitions and functionality in the OpenACC
 *  adapter.
 */

#ifndef SCOREP_OPENACC_H
#define SCOREP_OPENACC_H

/**
 * Initialize OpenACC wrapper handling.
 *
 * We assume that this function is not executed concurrently by multiple
 * threads.
 */
void
scorep_openacc_handler_init( void );

/**
 * Finalize OpenACC wrapper handling.
 */
void
scorep_openacc_handler_finalize( void );

#endif  /* SCOREP_OPENACC_H */

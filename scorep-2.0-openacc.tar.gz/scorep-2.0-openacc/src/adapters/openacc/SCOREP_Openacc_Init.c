/*
 * This file is part of the Score-P software (http://www.score-p.org)
 *
 * Copyright (c) 2014-2016,
 * Technische Universitaet Dresden, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license. See the COPYING file in the package base
 * directory for details.
 *
 */

/**
 *  @file
 *
 *  This file contains the implementation of the initialization functions of the
 *  OpenACC adapter.
 */

#include <config.h>
#include <SCOREP_RuntimeManagement.h>
#include <SCOREP_InMeasurement.h>
#include <SCOREP_Definitions.h>
#include <SCOREP_Events.h>
#include "SCOREP_Config.h"
#include "SCOREP_Types.h"
#include "SCOREP_Openacc_Init.h"

#include <UTILS_Error.h>
#define SCOREP_DEBUG_MODULE_NAME OPENACC
#include <UTILS_Debug.h>

#include "scorep_openacc.h"

#include "scorep_openacc_confvars.h"
#include "scorep_openacc_confvars.inc.c"



/** Registers the required configuration variables of the OpenACC adapter
    to the measurement system.
 */
static SCOREP_ErrorCode
openacc_subsystem_register( size_t subsystem_id )
{
    UTILS_DEBUG( "Register environment variables" );

    return SCOREP_ConfigRegister( "openacc", scorep_openacc_configs );
}


/** De-registers the OpenACC adapter. */
static void
openacc_subsystem_end( void )
{
    SCOREP_IN_MEASUREMENT_INCREMENT();

    UTILS_DEBUG_ENTRY();

    if ( scorep_openacc_features > 0 )
    {
        scorep_openacc_handler_finalize();
    }

    SCOREP_IN_MEASUREMENT_DECREMENT();
}

/** Initializes the OpenACC subsystem. */
static SCOREP_ErrorCode
openacc_subsystem_init( void )
{
    UTILS_DEBUG( "Selected options: %llu", scorep_openacc_features );

    SCOREP_Paradigms_RegisterParallelParadigm(
        SCOREP_PARADIGM_OPENACC,
        SCOREP_PARADIGM_CLASS_ACCELERATOR,
        "OpenACC",
        SCOREP_PARADIGM_FLAG_RMA_ONLY );

    if ( scorep_openacc_features > 0 )
    {
        //SCOREP_RegisterExitCallback( openacc_finalize_callback );

        scorep_openacc_handler_init();
    }

    return SCOREP_SUCCESS;
}

/** Initializes the location specific data of the OpenACC adapter */
static SCOREP_ErrorCode
openacc_subsystem_init_location( SCOREP_Location* location,
                                 SCOREP_Location* parent )
{
    return SCOREP_SUCCESS;
}

/** Collect locations involved in OpenACC communication. */
static SCOREP_ErrorCode
openacc_subsystem_pre_unify( void )
{
    // only if OpenACC communication is enabled for recording
    /*if ( scorep_openacc_record_memcpy  )
       {
        scorep_openacc_define_locations();
       }*/

    return SCOREP_SUCCESS;
}

/** Finalizes the OpenACC unification. */
static SCOREP_ErrorCode
openacc_subsystem_post_unify( void )
{
    /*if ( scorep_openacc_features > 0 )
       {
        scorep_openacc_define_group();
       }*/

    return SCOREP_SUCCESS;
}


SCOREP_Subsystem SCOREP_Subsystem_OpenaccAdapter =
{
    .subsystem_name          = "OPENACC",
    .subsystem_register      = &openacc_subsystem_register,
    .subsystem_end           = &openacc_subsystem_end,
    .subsystem_init          = &openacc_subsystem_init,
    .subsystem_init_location = &openacc_subsystem_init_location,
    .subsystem_pre_unify     = &openacc_subsystem_pre_unify,
    .subsystem_post_unify    = &openacc_subsystem_post_unify
};

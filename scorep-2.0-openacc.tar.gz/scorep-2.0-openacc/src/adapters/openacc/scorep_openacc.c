/*
 * This file is part of the Score-P software (http://www.score-p.org)
 *
 * Copyright (c) 2014-2016,
 * Technische Universitaet Dresden, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license. See the COPYING file in the package base
 * directory for details.
 *
 */

/**
 *  @file
 *
 *  Implementation of the handlers for the OpenACC tools interface.
 */

#include <config.h>

#include <UTILS_CStr.h>
#include <UTILS_Error.h>
#include <UTILS_Debug.h>

#include <SCOREP_Mutex.h>

#include <SCOREP_RuntimeManagement.h>
#include "SCOREP_Definitions.h"
#include "SCOREP_Memory.h"
#include "SCOREP_Events.h"

#include "scorep_openacc.h"
#include "scorep_openacc_confvars.h"

#include <string.h>
#include <inttypes.h>

#include <openacc.h>
#include <acc_prof.h>

/* thread (un)locking macros for OpenACC wrapper */
//#define ACC_LOCK() SCOREP_MutexLock( scorep_openacc_mutex )
//#define ACC_UNLOCK() SCOREP_MutexUnlock( scorep_openacc_mutex )

/***** OpenACC region hash table *****/

/* Default size for the OpenACC region hash table */
#define REGION_HASHTABLE_SIZE 1024

/*
 * The key of the hash node is a string, the value the corresponding region handle.
 * It is used to store region names with its corresponding region handles.
 */
typedef struct region_hash_node
{
    char*                    name;   /**< name of the symbol */
    SCOREP_RegionHandle      region; /**< associated region handle */
    struct region_hash_node* next;   /**< bucket for collision */
} region_hash_node;

static region_hash_node* region_hashtab[ REGION_HASHTABLE_SIZE ];

static void*
region_hash_get( const char* name );
static void*
region_hash_put( const char*         name,
                 SCOREP_RegionHandle region );

/***** END: OpenACC region hash table *****/

//static SCOREP_Mutex scorep_openacc_mutex = NULL;

static void
handle_runtime_shutdown( acc_prof_info*  profInfo,
                         acc_event_info* eventInfo,
                         acc_api_info*   apiInfo );

static void
handle_enter_region( acc_prof_info*,
                     acc_event_info*,
                     acc_api_info* );

static void
handle_leave_region( acc_prof_info*,
                     acc_event_info*,
                     acc_api_info* );

static void
handle_start_launch( acc_prof_info*,
                     acc_event_info*,
                     acc_api_info* );

static void
handle_start_dataload( acc_prof_info*,
                       acc_event_info*,
                       acc_api_info* );

static void
handle_wait( acc_prof_info*,
             acc_event_info*,
             acc_api_info* );

static void
handle_alloc( acc_prof_info*,
              acc_event_info*,
              acc_api_info* );

static void
set_features( void );


bool scorep_openacc_record_regions  = false;
bool scorep_openacc_record_enqueue  = false;
bool scorep_openacc_record_wait     = false;
bool scorep_openacc_record_memusage = false;


/* initialization and finalization flags */
static bool acc_handler_initialized = false;
static bool acc_handler_finalized   = false;


SCOREP_SourceFileHandle acc_region_file_handle = SCOREP_INVALID_SOURCE_FILE;

typedef struct thread_data_t
{
    int                   threadId;
    SCOREP_RegionHandle*  region_stack;
    size_t                region_stack_depth;
    size_t                region_stack_max;
    struct thread_data_t* next;
}thread_data_t;

static thread_data_t* region_stacks = NULL;

static void
region_push( SCOREP_RegionHandle,
             int );
static SCOREP_RegionHandle
region_pop( int );

static thread_data_t*
create_thread_data( int hostThreadId );

static thread_data_t*
get_thread_data( int hostThreadId );

//SCOREP_SamplingSetHandle acc_memusage_sampling_set =
//    SCOREP_INVALID_SAMPLING_SET;

/*
 * Initialize OpenACC event handler.
 *
 * (We assume that this function cannot be executed concurrently by multiple
 * threads.)
 */
void
scorep_openacc_handler_init( void )
{
    if ( !acc_handler_initialized )
    {
        UTILS_DEBUG_PRINTF( SCOREP_DEBUG_OPENACC, "[OpenACC] Initialize handler." );

        set_features();

        if ( scorep_openacc_features )
        {
#if defined ( USE_REGION_STACK )
            // create region stack for initial thread (0)
            region_stacks = create_thread_data( 0 );
#endif

            /* OpenACC device memory usage
               if ( scorep_openacc_record_memusage )
               {
                SCOREP_MetricHandle metric_handle =
                    SCOREP_Definitions_NewMetric( "acc_device_mem_usage",
                                                  "OpenCC device memory usage",
                                                  SCOREP_METRIC_SOURCE_TYPE_OTHER,
                                                  SCOREP_METRIC_MODE_ABSOLUTE_NEXT,
                                                  SCOREP_METRIC_VALUE_UINT64,
                                                  SCOREP_METRIC_BASE_DECIMAL,
                                                  1,
                                                  "Byte",
                                                  SCOREP_METRIC_PROFILING_TYPE_EXCLUSIVE );

                acc_memusage_sampling_set =
                    SCOREP_Definitions_NewSamplingSet( 1, &metric_handle,
                                                       SCOREP_METRIC_OCCURRENCE_SYNCHRONOUS, SCOREP_SAMPLING_SET_GPU );
               }*/

            acc_handler_initialized = true;
        }
    }
}


void
scorep_openacc_handler_finalize( void )
{
    if ( !acc_handler_finalized && acc_handler_initialized )
    {
        UTILS_DEBUG_PRINTF( SCOREP_DEBUG_OPENACC, "[OpenACC] Finalize handler." );

        acc_handler_finalized = true;
    }
}

/*
 *
 */
void
acc_register_library( acc_prof_reg acc_register, acc_prof_reg acc_unregister, acc_prof_lookup lookup )
{
    UTILS_DEBUG_PRINTF( SCOREP_DEBUG_OPENACC,
                        "[OpenACC] Register profiling library." );

    // Initialize the measurement system, if necessary
    if ( !SCOREP_IsInitialized() )
    {
        SCOREP_InitMeasurement();
    }

    scorep_openacc_handler_init();

    // register finalize function to be called when OpenACC runtime shuts down
    if ( scorep_openacc_features )
    {
        acc_register( acc_ev_runtime_shutdown, handle_runtime_shutdown, 0 );
    }

    if ( scorep_openacc_record_regions )
    {
        //register OpenACC device initialization and shutdown
        acc_register( acc_ev_device_init_start, handle_enter_region, 0 );
        acc_register( acc_ev_device_init_end, handle_leave_region, 0 );
        acc_register( acc_ev_device_shutdown_start, handle_enter_region, 0 );
        acc_register( acc_ev_device_shutdown_end, handle_leave_region, 0 );

        //register OpenACC regions
        acc_register( acc_ev_compute_construct_start, handle_enter_region, 0 );
        acc_register( acc_ev_update_start, handle_enter_region, 0 );
        acc_register( acc_ev_enter_data_start, handle_enter_region, 0 );
        acc_register( acc_ev_exit_data_start, handle_enter_region, 0 );
        acc_register( acc_ev_compute_construct_end, handle_leave_region, 0 );
        acc_register( acc_ev_update_end, handle_leave_region, 0 );
        acc_register( acc_ev_enter_data_end, handle_leave_region, 0 );
        acc_register( acc_ev_exit_data_end, handle_leave_region, 0 );
    }

    if ( scorep_openacc_record_enqueue )
    {
        // register kernel launch
        acc_register( acc_ev_enqueue_launch_start, handle_enter_region, 0 );
        acc_register( acc_ev_enqueue_launch_end, handle_leave_region, 0 );

        // register data transfers
        acc_register( acc_ev_enqueue_upload_start, handle_enter_region, 0 );
        acc_register( acc_ev_enqueue_upload_end, handle_leave_region, 0 );
        acc_register( acc_ev_enqueue_download_start, handle_enter_region, 0 );
        acc_register( acc_ev_enqueue_download_end, handle_leave_region, 0 );
    }

    if ( scorep_openacc_record_wait )
    {
        // register wait handlers
        acc_register( acc_ev_wait_start, handle_enter_region, 0 );
        acc_register( acc_ev_wait_end, handle_leave_region, 0 );
    }

    if ( scorep_openacc_record_memusage )
    {
        // register memory allocations
        acc_register( acc_ev_create, handle_alloc, 0 );
        acc_register( acc_ev_alloc, handle_alloc, 0 );
        acc_register( acc_ev_delete, handle_alloc, 0 );
        acc_register( acc_ev_free, handle_alloc, 0 );
    }
} /* acc_register_library */

static void
handle_runtime_shutdown( acc_prof_info* profInfo, acc_event_info* eventInfo, acc_api_info* apiInfo )
{
    scorep_openacc_handler_finalize();
}

static void
handle_enter_region( acc_prof_info* profInfo, acc_event_info* eventInfo, acc_api_info* apiInfo )
{
    char*  region_type        = NULL;
    size_t region_name_length = 0;

    if ( profInfo == NULL || !acc_handler_initialized )
    {
        return;
    }

    switch ( profInfo->event_type )
    {
        case acc_ev_device_init_start:
            region_type        = "acc_init";
            region_name_length = 8;
            break;
        case acc_ev_device_shutdown_start:
            region_type        = "acc_shutdown";
            region_name_length = 12;
            break;
        case acc_ev_compute_construct_start:
            region_type        = "acc_compute_construct";
            region_name_length = 21;
            break;
        case acc_ev_update_start:
            region_type        = "acc_update_construct";
            region_name_length = 20;
            break;
        case acc_ev_enter_data_start:
            region_type        = "acc_data_construct_enter";
            region_name_length = 24;
            break;
        case acc_ev_exit_data_start:
            region_type        = "acc_data_construct_exit";
            region_name_length = 23;
            break;
        case acc_ev_enqueue_launch_start:
            region_type        = "acc_launch_kernel";
            region_name_length = 17;
            break;
        case acc_ev_enqueue_upload_start:
            region_type        = "acc_upload";
            region_name_length = 10;
            break;
        case acc_ev_enqueue_download_start:
            region_type        = "acc_download";
            region_name_length = 12;
            break;
        case acc_ev_wait_start:
            region_type        = "acc_wait";
            region_name_length = 8;
            break;
        default:
            region_type        = "acc_unknown";
            region_name_length = 11;
            break;
    }

    char* region_name = NULL;

    //todo: eventInfo->other_event.implicit;

    if ( profInfo->src_file && profInfo->line_no )
    {
        const char* file_name =  strrchr( profInfo->src_file, '/' );

        if ( NULL == file_name )
        {
            file_name = profInfo->src_file;
        }
        else
        {
            // start with character after the last '/'
            file_name += 1;
        }

        region_name_length += strlen( file_name );

        region_name_length += 10; // TODO: line number length

        region_name = ( char* )SCOREP_Memory_AllocForMisc( region_name_length * sizeof( char ) );

        // compose OpenACC region name
        if ( -1 == snprintf( region_name, region_name_length + 1, "%s@%s:%i",
                             region_type, file_name, profInfo->line_no ) )
        {
            UTILS_WARNING( "[OpenACC] Could not create region name for %s!", region_type );
            region_name = region_type;
        }
    }
    else
    {
        region_name = region_type;
    }

    SCOREP_RegionHandle regionHandle = SCOREP_INVALID_REGION;
    region_hash_node*   hashNode     = NULL;

    // get the Score-P region ID for the region
    hashNode = region_hash_get( region_name );
    if ( hashNode )
    {
        regionHandle = hashNode->region;
    }
    else
    {
        if ( region_name == NULL )
        {
            region_name = "acc_unknown";
        }

        regionHandle = SCOREP_Definitions_NewRegion(
            region_name, NULL,
            acc_region_file_handle, 0, 0,
            SCOREP_PARADIGM_OPENACC, SCOREP_REGION_FUNCTION );

        hashNode = region_hash_put( region_name, regionHandle );
    }

#if defined ( USE_REGION_STACK )
    // put the region on the stack
    region_push( regionHandle, profInfo->thread_id );
#else
    // pass Score-P region handle to corresponding leave (causes compiler warning)
    eventInfo->other_event.tool_info = ( void* )regionHandle;
#endif

    SCOREP_EnterRegion( regionHandle );

    /*
       if( profinfo->funcname )
        fprintf( stderr, " function=%s", profinfo->funcname );

       if( profinfo->lineno ) fprintf( stderr, " line=%d", profinfo->lineno );
        fprintf( stderr, " device=%u", profinfo->devnum );

       if( profinfo->async != acc_async_sync )
        fprintf( stderr, " queue=%lu", profinfo->asyncmap );

       fprintf( stderr, "\n" );
     */
}

/**
 * Handle OpenACC leave events. As regions should be perfectly nested, we just
 * need to the exit event with the region handle passed in from the tool info
 * field.
 */
static void
handle_leave_region( acc_prof_info* profinfo, acc_event_info* eventInfo, acc_api_info* apiinfo )
{
    SCOREP_RegionHandle regionHandle = SCOREP_INVALID_REGION;

#if defined ( USE_REGION_STACK )
    regionHandle = region_pop( profinfo->thread_id );
#else
    regionHandle = ( uint32_t )eventInfo->other_event.tool_info;
#endif

    SCOREP_ExitRegion( regionHandle );
}

// allocations
static void
handle_alloc( acc_prof_info* profinfo, acc_event_info* eventinfo, acc_api_info* apiinfo )
{
    acc_data_event_info* datainfo = ( acc_data_event_info* )eventinfo;

    if ( datainfo->bytes )
    {
        // add "datainfo->bytes" to allocated memory counter

        switch ( profinfo->event_type )
        {
            case acc_ev_create:
            case acc_ev_alloc:
                //SCOREP_TriggerCounterUint64( acc_memusage_sampling_set,
                //                             datainfo->bytes );

                break;
            case acc_ev_delete:
            case acc_ev_free:
                //SCOREP_TriggerCounterUint64( acc_memusage_sampling_set,
                //                             datainfo->bytes );
                break;
            default:
                break;
        }
    }

    /*
       fprintf( stderr, " device=%u", profinfo->devnum );
       if ( datainfo->varname )
       {
        fprintf( stderr, " variable=%s", datainfo->varname );
       }
       if ( profinfo->async != acc_async_sync )
       {
        fprintf( stderr, " queue=%lu", profinfo->asyncmap );
       }
       fprintf( stderr, "\n" );*/
}

static void
set_features()
{
    UTILS_DEBUG_PRINTF( SCOREP_DEBUG_OPENACC, "[OpenACC] Setup features" );

    acc_region_file_handle =
        SCOREP_Definitions_NewSourceFile( "OPENACC" );

    /* check for OpenACC regions */
    if ( scorep_openacc_features & SCOREP_OPENACC_FEATURE_REGIONS )
    {
        scorep_openacc_record_regions = true;
    }

    /* check for OpenACC enqueue operations */
    if ( scorep_openacc_features & SCOREP_OPENACC_FEATURE_ENQUEUE )
    {
        scorep_openacc_record_enqueue = true;
    }

    /* check for OpenACC synchronization */
    if ( scorep_openacc_features & SCOREP_OPENACC_FEATURE_WAIT )
    {
        scorep_openacc_record_wait = true;
    }

    /* check for OpenACC device memory usage */
    if ( scorep_openacc_features & SCOREP_OPENACC_FEATURE_MEMUSAGE )
    {
        scorep_openacc_record_memusage = true;
    }
}

/******************************************************************************/
/* Implementation of OpenACC region hashing.
   /******************************************************************************/

/** @brief
 * SDBM hash function. (better than DJB2 for table size 2^10)
 *
 * @param str               Pointer to a string to be hashed
 *
 * @return Returns hash code of @ str.
 */
static unsigned int
hash_string( const char* str )
{
    unsigned int hash = 0;
    int          c;

    while ( ( c = *str++ ) )
    {
        hash = c + ( hash << 6 ) + ( hash << 16 ) - hash;
    }

    return hash;
}

/** @brief
 * Puts a string into the hash table
 *
 * @param name   Pointer to a string to be stored in the hash table.
 * @param region Region handle.
 *
 * @return Return pointer to the created hash node.
 */
static void*
region_hash_put( const char* name, SCOREP_RegionHandle region )
{
    uint32_t id = ( uint32_t )hash_string( name ) % REGION_HASHTABLE_SIZE;

    // PGC-W-0155-Pointer value created from a nonlong integral type
    region_hash_node* add =
        ( region_hash_node* )SCOREP_Memory_AllocForMisc( sizeof( region_hash_node ) );

    add->name            = UTILS_CStr_dup( name );         /* does an implicit malloc */
    add->region          = region;
    add->next            = region_hashtab[ id ];
    region_hashtab[ id ] = add;

    return add;
}

/** @brief
 * Get a string from the OpenACC region hash table
 *
 * @param name Pointer to a string to be retrieved from the hash table.
 *
 * @return Return pointer to the retrieved hash node.
 */
static void*
region_hash_get( const char* name )
{
    uint32_t id = ( uint32_t )hash_string( name )  % REGION_HASHTABLE_SIZE;

    region_hash_node* curr = region_hashtab[ id ];

    while ( curr )
    {
        if ( strcmp( curr->name, name ) == 0 )
        {
            return curr;
        }

        curr = curr->next;
    }

    return NULL;
}

#if defined ( USE_REGION_STACK )

#define REGION_STACK_INITIAL_DEPTH 32

/** @brief
 * Allocates and initializes thread data for the given host thread ID
 *
 * @param hostThreadId ID of the host thread (starting with zero)
 *
 * @return pointer to the allocated thread data
 */
static thread_data_t*
create_thread_data( int hostThreadId )
{
    thread_data_t* thread_data =
        ( thread_data_t* )malloc( sizeof( thread_data_t ) );

    thread_data->next               = NULL;
    thread_data->threadId           = hostThreadId;
    thread_data->region_stack_depth = 0;
    thread_data->region_stack_max   = REGION_STACK_INITIAL_DEPTH;

    // allocate region stack (currently 32)
    thread_data->region_stack =
        ( SCOREP_RegionHandle* )malloc( REGION_STACK_INITIAL_DEPTH * sizeof( SCOREP_RegionHandle ) );

    return thread_data;
}

/** @brief
 * Retrieves the thread data that correspond to the given host thread ID.
 *
 * @param hostThreadId ID of the host thread (starting with zero)
 *
 * @return pointer to the thread data (for the given host thread ID)
 */
static thread_data_t*
get_thread_data( int hostThreadId )
{
    thread_data_t* thread_data = region_stacks;
    while ( thread_data )
    {
        if ( thread_data->threadId == hostThreadId )
        {
            return thread_data;
        }

        thread_data = thread_data->next;
    }

    return NULL;
}

/** @brief
 * Pushes a Score-P region handle on the corresponding thread's region stack.
 *
 * @param regionHandle Score-P region handle to be pushed
 * @param hostThreadId ID of the host thread (starting with zero)
 */
static void
region_push( SCOREP_RegionHandle regionHandle, int hostThreadId )
{
    thread_data_t* thread_data = get_thread_data( hostThreadId );

    if ( thread_data )
    {
        // realloc with double stack size if necessary
        if ( thread_data->region_stack_depth >= thread_data->region_stack_max )
        {
            thread_data->region_stack_max *= 2;
            thread_data->region_stack      =
                ( SCOREP_RegionHandle* )realloc( thread_data, thread_data->region_stack_max * sizeof( SCOREP_RegionHandle ) );

            UTILS_WARNING( "[OpenACC] Reallocated region stack!" );
        }
    }
    else
    {
        // allocate new region stack (first region on this thread)
        thread_data = create_thread_data( hostThreadId );

        // TODO: append (currently prepend)
        thread_data->next = region_stacks;
        region_stacks     = thread_data;
    }

    // push the region data on the current thread's stack
    thread_data->region_stack[ thread_data->region_stack_depth ] = regionHandle;
    thread_data->region_stack_depth++;
}

/** @brief
 * Pop a Score-P region handle from the corresponding thread's region stack.
 *
 * @param hostThreadId ID of the host thread (starting with zero)
 *
 * @return Score-P region handle that has been popped from the thread's region stack
 */
static SCOREP_RegionHandle
region_pop( int hostThreadId )
{
    thread_data_t* thread_data = get_thread_data( hostThreadId );

    if ( thread_data )
    {
        thread_data->region_stack_depth--;
        return thread_data->region_stack[ thread_data->region_stack_depth ];
    }
    else
    {
        UTILS_WARNING( "[OpenACC] No region stack for thread %d found!", hostThreadId );
    }
}
#endif

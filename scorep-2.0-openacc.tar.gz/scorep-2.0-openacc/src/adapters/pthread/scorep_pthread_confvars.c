/*
 * This file is part of the Score-P software (http://www.score-p.org)
 *
 * Copyright (c) 2014,
 * Forschungszentrum Juelich GmbH, Germany
 *
 * Copyright (c) 2015,
 * Technische Universitaet Dresden, Germany
 *
 * This software may be modified and distributed under the terms of
 * a BSD-style license. See the COPYING file in the package base
 * directory for details.
 *
 */


/**
 * @file
 *
 *
 */

#include <config.h>

#include <SCOREP_Subsystem.h>


/** Struct which contains the adapter initialization and finalization functions for the
    PTHREAD adapter.
 */
const SCOREP_Subsystem SCOREP_Subsystem_PthreadAdapter =
{
    .subsystem_name = "PTHREAD Adapter / Version 1.0 (config variables only)",
};
